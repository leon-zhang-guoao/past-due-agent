# Atlas query playbook — 3.5.0

Retained reads copy the `analyze_result` object and the SQL in
[result-reader.md](result-reader.md).
EQL stays `{:entity ... :query ...}` inside `execute_eql.query`.

## Choose the fact capability

Requested reports, including nontrigger dates and Vendor sets: read
[report planning](report-planning.md) and select the semantically equivalent
interface: original report for positive Top N/single Vendor, v2 for added selection
or coverage requirements. No-alert is independent of interface choice.
Report requests bypass alert selection; data and pair validity still apply.
Standard: monitor/history → pinned report-query/rows. Interactive: discovered
explore-v3-query/rows preferred; read [v3 contract](explore-v3.md) and
[complete EQL](explore-v3-query.eql). v2 and old explore remain compatible. Read
[interactive planning](interactive-planning.md) and [v2 contract](explore-v2.md)
for selection sets, source pages and equivalent alternate paths.
The retained 3.2 long-text endpoints are compatibility-only. Read the active
section, not all examples. Use live list_entities/list_attributes/tool schemas and
reuse discovery within the same environment. Dates/Vendors below are examples,
not run defaults. EQL wrapper is `{:entity ... :query ...}`, never Datalog.

The examples use plain joins accepted by the observed Studio. They are NOT a
verified paging API. Report3.3 source default/max is1000; compact Top10 bound is221. Other
collections retain default200/max1000 except explore-v2/v3, whose SQL pages have
at most500 non-control rows plus CONTROL with transport default/max1000.
Older report deployments may default200
and cut off a221-row report unless supported source paging/limit is supplied.
MCP source paging/sorting must use its actually supported schema. Do not paste
parameterized joins into Studio after semantic.studio/query-shape rejection.
Incomplete source results cannot be repaired by paging their truncated handle.

Complete plain-join projections for monitor/report/history are in
[structured-queries.eql](structured-queries.eql); below are readable examples.
Read the complete example for HISTORICAL_FULL/explicit-target TEST: the short
event-list projection below alone cannot support Country count/ratio cross-checks.

## Monitor (standard route)
```clojure
{:entity {:pastdue.monitor-query/calendar-mode "WEEKDAYS"
          :pastdue.monitor-query/relative-change-threshold 0.10}
 :query [{:pastdue.monitor-query/countries
           [:pastdue.monitor-fact/country-code
            :pastdue.monitor-fact/target-snapshot-date
            :pastdue.monitor-fact/previous-snapshot-date
            :pastdue.monitor-fact/calendar-mode
            :pastdue.monitor-fact/target-past-due-count
            :pastdue.monitor-fact/previous-past-due-count
            :pastdue.monitor-fact/target-open-count
            :pastdue.monitor-fact/previous-open-count
            :pastdue.monitor-fact/target-past-due-ratio
            :pastdue.monitor-fact/previous-past-due-ratio
            :pastdue.monitor-fact/relative-ratio-change
            :pastdue.monitor-fact/percentage-point-change
            :pastdue.monitor-fact/business-status
            :pastdue.monitor-fact/data-status
            :pastdue.monitor-fact/expected-target-date
            :pastdue.monitor-fact/target-lag-workdays
            :pastdue.monitor-fact/missing-workdays-between
            :pastdue.monitor-fact/has-comparable-snapshots
            :pastdue.monitor-fact/snapshot-gap-days]}
 ]}
```
Consume complete Country facts before locally selecting authorized US/CA. Use
trusted runtime America/Los_Angeles today, not latest snapshot as a clock.
Normal daily only drills TRIGGERED/ZERO_BASELINE_INCREASE with valid comparable
positive Open and data OK/DELAYED. Test forces applicable valid pairs, warns stale.
An explicitly requested test/report target uses history-query/comparisons with
range-start-date=range-end-date=target and the same full Country projection.
This returns its actual prior eligible snapshot even if the target didn't trigger.
Do not use trigger-events to find nontrigger test pairs or silently substitute
the latest monitor dates. An arbitrary explicit P/T uses explore PAIR/EXPLICIT.

## Report (standard route, seven inputs)
```clojure
{:entity {:pastdue.report-query/country-code "CA"
          :pastdue.report-query/target-snapshot-date "2026-10-26"
          :pastdue.report-query/previous-snapshot-date "2026-10-23"
          :pastdue.report-query/calendar-mode "WEEKDAYS"
          :pastdue.report-query/selection-mode "POSITIVE_TOP_N"
          :pastdue.report-query/top-n 10
          :pastdue.report-query/vendor-code 0}
 :query [{:pastdue.report-query/rows
           [:pastdue.report-fact/scope-key
            :pastdue.report-fact/record-type
            :pastdue.report-fact/country-code
            :pastdue.report-fact/vendor-code
            :pastdue.report-fact/vendor-name
            :pastdue.report-fact/target-snapshot-date
            :pastdue.report-fact/previous-snapshot-date
            :pastdue.report-fact/calendar-mode
            :pastdue.report-fact/selection-mode
            :pastdue.report-fact/metric-version
            :pastdue.report-fact/business-timezone
            :pastdue.report-fact/queried-at-local
            :pastdue.report-fact/scope-status
            :pastdue.report-fact/dimension
            :pastdue.report-fact/eta-value
            :pastdue.report-fact/row-kind
            :pastdue.report-fact/contribution-rank
            :pastdue.report-fact/selected-vendor-count
            :pastdue.report-fact/target-past-due-count
            :pastdue.report-fact/previous-past-due-count
            :pastdue.report-fact/past-due-count-change
            :pastdue.report-fact/target-open-count
            :pastdue.report-fact/previous-open-count
            :pastdue.report-fact/target-country-open
            :pastdue.report-fact/previous-country-open
            :pastdue.report-fact/target-country-past-due-count
            :pastdue.report-fact/previous-country-past-due-count
            :pastdue.report-fact/target-country-ratio
            :pastdue.report-fact/previous-country-ratio
            :pastdue.report-fact/target-vendor-ratio
            :pastdue.report-fact/previous-vendor-ratio
            :pastdue.report-fact/target-country-contribution
            :pastdue.report-fact/previous-country-contribution
            :pastdue.report-fact/delta-country-contribution
            :pastdue.report-fact/positive-contribution-share
            :pastdue.report-fact/selected-positive-coverage
            :pastdue.report-fact/display-rank
            :pastdue.report-fact/expected-bucket-count
            :pastdue.report-fact/other-bucket-count
            :pastdue.report-fact/increase-total
            :pastdue.report-fact/decrease-total
            :pastdue.report-fact/net-change
            :pastdue.report-fact/previous-total
            :pastdue.report-fact/target-total
            :pastdue.report-fact/previous-expected-total
            :pastdue.report-fact/target-expected-total
            :pastdue.report-fact/counts-match
            :pastdue.report-fact/required
            :pastdue.report-fact/past-due-count-relative-change
            :pastdue.report-fact/expected-record-count
            :pastdue.report-fact/row-ordinal]}
 ]}
```
Read one COUNTRY_CONTROL before consuming metrics; it need not be physically
first. Then group VENDOR_METRICS and summaries by Country+Vendor+pair, and
VENDOR_CHECK by dimension=code/source/us. BUCKET rank≤5 and OTHER rank6 are
server summaries. expected-record-count includes the control; raw bucket
coverage = BUCKET rows + Other's other-bucket-count, not summary row count.
Required counts-match/total/expected-total checks are mandatory even when empty.
Reconcile COUNTRY_CONTROL target/previous-country-past-due-count, -open and
-ratio to the pinned monitor/history facts before combining captures. Drift is
explicit PARTIAL/UNVERIFIED unless paired raw evidence proves a hard conflict;
queried-at-local is capture evidence, never a cross-query transaction guarantee.
US summary is already joint Code=US×Source for EVERY Country. Do not call separate legacy dimension
collections. SINGLE_VENDOR changes selection-mode, actual vendor-code and top-n=1;
it has no positive-only filter. Pin nearest-eligible P from monitor/history.

## Flexible analysis: all 20 inputs, explicit denominator and complete projection
This example asks for all current Vendor×Code shares within each Vendor.
```clojure
{:entity {:pastdue.explore-query/country-code "CA"
          :pastdue.explore-query/time-basis "CURRENT"
          :pastdue.explore-query/target-snapshot-date "1970-01-01"
          :pastdue.explore-query/previous-snapshot-date "1970-01-01"
          :pastdue.explore-query/range-start-date "1970-01-01"
          :pastdue.explore-query/range-end-date "1970-01-01"
          :pastdue.explore-query/calendar-mode "WEEKDAYS"
          :pastdue.explore-query/pair-policy "PREVIOUS_AVAILABLE"
          :pastdue.explore-query/grain "VENDOR_CODE"
          :pastdue.explore-query/vendor-code 0
          :pastdue.explore-query/eta-code-filter ""
          :pastdue.explore-query/source-filter ""
          :pastdue.explore-query/department-type-filter ""
          :pastdue.explore-query/master-primary-filter ""
          :pastdue.explore-query/master-manager-filter ""
          :pastdue.explore-query/denominator-scope "WITHIN_VENDOR"
          :pastdue.explore-query/ranking-metric "NONE"
          :pastdue.explore-query/sort-direction "ASC"
          :pastdue.explore-query/change-selection "ALL"
          :pastdue.explore-query/top-n 0}
 :query [{:pastdue.explore-query/rows
           [:pastdue.explore-fact/scope-key
            :pastdue.explore-fact/record-type
            :pastdue.explore-fact/scope-status
            :pastdue.explore-fact/country-code
            :pastdue.explore-fact/vendor-code
            :pastdue.explore-fact/vendor-name
            :pastdue.explore-fact/target-snapshot-date
            :pastdue.explore-fact/previous-snapshot-date
            :pastdue.explore-fact/calendar-mode
            :pastdue.explore-fact/time-basis
            :pastdue.explore-fact/grain
            :pastdue.explore-fact/eta-code
            :pastdue.explore-fact/eta-source
            :pastdue.explore-fact/denominator-scope
            :pastdue.explore-fact/metric-version
            :pastdue.explore-fact/organization-basis
            :pastdue.explore-fact/business-timezone
            :pastdue.explore-fact/queried-at-local
            :pastdue.explore-fact/target-past-due-count
            :pastdue.explore-fact/previous-past-due-count
            :pastdue.explore-fact/target-open-count
            :pastdue.explore-fact/previous-open-count
            :pastdue.explore-fact/target-ratio-denominator
            :pastdue.explore-fact/previous-ratio-denominator
            :pastdue.explore-fact/target-share-denominator
            :pastdue.explore-fact/previous-share-denominator
            :pastdue.explore-fact/target-country-open
            :pastdue.explore-fact/previous-country-open
            :pastdue.explore-fact/past-due-count-change
            :pastdue.explore-fact/target-past-due-ratio
            :pastdue.explore-fact/previous-past-due-ratio
            :pastdue.explore-fact/target-past-due-share
            :pastdue.explore-fact/previous-past-due-share
            :pastdue.explore-fact/past-due-count-relative-change
            :pastdue.explore-fact/past-due-ratio-change
            :pastdue.explore-fact/delta-country-contribution
            :pastdue.explore-fact/selection-rank
            :pastdue.explore-fact/expected-record-count
            :pastdue.explore-fact/row-ordinal]}
 ]}
```
One CONTROL plus FACT rows, with expected-record-count including CONTROL.
Non-PAIR previous date=1970-01-01 and previous counts are placeholders, not a
zero baseline to diagnose. Sparse control default values are not observations.
Use returned business-timezone/queried-at-local and actual DST label/offset from
trusted runtime; an ambiguous fall-back local timestamp without its instant/offset
must not be resolved by guessing. Always project scope-key: JSON tuple of all
required inputs, in declaration order. Retain it with original inputs, check exact
consistency across captured rows/pages; it is not a source revision or watermark.

Resolve other requests by changing the input entity above, preserving all 20
inputs and the same explicit projection (no wildcard or imaginary fields):

| Intent | Changed inputs |
|---|---|
| Current count Top 10 | grain=VENDOR, denominator-scope=COUNTRY_ALL, ranking-metric=PAST_DUE_COUNT, sort-direction=DESC, top-n=10 |
| Single snapshot | time-basis=SNAPSHOT, target-snapshot-date=2026-10-26; keep inactive previous/range sentinels |
| Exact two dates, declining counts | time-basis=PAIR, target=2026-10-26, previous=2026-10-22, pair-policy=EXPLICIT, grain=VENDOR, denominator=COUNTRY_ALL, ranking=COUNT_CHANGE, direction=ASC, change-selection=NEGATIVE, top-n=10 (use full input names above) |
| Nearest previous, contribution growth | time-basis=PAIR, target-snapshot-date=2026-10-26, previous sentinel, pair-policy=PREVIOUS_AVAILABLE, grain=VENDOR, denominator-scope=COUNTRY_ALL, ranking-metric=CONTRIBUTION_CHANGE, sort-direction=DESC, change-selection=POSITIVE, top-n=10 |
| Daily Country stocks | time-basis=RANGE, range-start-date=2026-10-19, range-end-date=2026-10-26, grain=COUNTRY, denominator-scope=COUNTRY_ALL, ranking-metric=NONE, top-n=0 |
| Vendor joint composition | grain=VENDOR_CODE_SOURCE, vendor-code=31420, denominator-scope=WITHIN_VENDOR, ranking-metric=NONE, top-n=0 |

These are illustrative input substitutions, not alternate EQL property aliases.
Use data-contract's exact enums. PAIR-only change selection is not meaningful on
CURRENT/SNAPSHOT/RANGE. WITHIN_VENDOR+COUNTRY is invalid, not silently reinterpreted.

## Historical events
```clojure
{:entity {:pastdue.history-query/country-code "US"
          :pastdue.history-query/calendar-mode "WEEKDAYS"
          :pastdue.history-query/range-start-date "2026-10-01"
          :pastdue.history-query/range-end-date "2026-10-26"
          :pastdue.history-query/relative-change-threshold 0.10}
 :query [{:pastdue.history-query/trigger-events
           [:pastdue.history-fact/country-code
            :pastdue.history-fact/target-snapshot-date
            :pastdue.history-fact/previous-snapshot-date
            :pastdue.history-fact/calendar-mode
            :pastdue.history-fact/business-status
            :pastdue.history-fact/data-status
            :pastdue.history-fact/relative-ratio-change]}
 ]}
```
For full historical reports project the discovered Country counts/Open/ratio and
quality fields just as in monitor, in the same history request. Choose latest
actual event per Country after all pages, not first row. Events-only stops here.


## Read layer 1: source collection coverage

Project expected-record-count, row-ordinal, scope-key and full identity for report/
explore. Use resolver stable ordinal ascending; report3.3 default/max1000, explore default200/max1000. Discover actual
source paging syntax before use; don't guess an EQL/Studio parameter shape. Keep
request scope/projection/order unchanged across pages. Expected counts must agree;
unique identities/ordinals across pages must cover the expected count. A retained
handle can be a single source page, not the full source population.

If the host has no supported way to fetch remaining source records, state the
specific source gap; don't mark a short final preview as complete or requery each
Vendor. The report3.3 default1000 (or supported explicit source limit1000) can contain a compact Top10 report, but does
not remove result-reader row/cell limits or guarantee cheap source execution.
Monitor/history lack expected-record-count/row-ordinal in their actual schema;
use actual source pagination/coverage metadata and discovered stable identity/order,
not invented fields. An incomplete history list cannot establish the latest event.

## Read layer 2: retained-result materialization

The only maintained retained-read arguments, typed SQL projections and paging
procedure are in [result-reader.md](result-reader.md). Read its active section,
not every query example. Known-schema reads can skip redundant discovery;
unknown columns need actual schema, never guessed aliases.

Interpret report rows as Country Control → Vendor Metrics → ETA summaries/checks;
this does not mandate three tool calls if the required fields are already read.
Original report keeps its typed read baseline; paged interfaces choose needed
typed fields or an optional full read based on actual size and truncation. Keep scope-key,
Country, Vendor, P/T, metric version,
record type and ordinal in every applicable projection. Source expected count is
validated against the union of retained partitions, not each partition separately.
Do not read Vendor placeholder zeros on COUNTRY_CONTROL as Country totals. Missing
fields require a corrected projection, not a reconciliation waiver. Inspect row
and cell truncation independently. Continue supported retained pages/ordinal
windows; source paging still follows layer 1 above. No source re-execution to
repair a retained preview limit, no metric/denominator/rank recomputation or joins.
The Skill does not install a tool-argument sanitizer or a report renderer.

## Binding, budgets and failures

Interpret record-type before fields: VENDOR_METRICS holds Vendor totals; summary
rows hold bucket counts. See data-contract.md binding table. Check dimension=us
for ANY Country, not only Country US; joint summaries never come from stitching
marginal Code/Source rows. Other stays a mixed remainder. A required=false zero
joint check is not failed. Read all applicable checks before Country diagnosis.

Use result-reader.md for page/fact progress and local recovery. One justified
changed correction per logical request; pagination isn't a retry, but it and
retained reads count toward execution cost in DAILY/HISTORICAL/TEST/INTERACTIVE.
Changing source limit/projection does not fix cancelled aggregation. Preserve
independent valid facts; nested errors count even if outer isError=false.
All modes: review plans after six distinct source scopes, not an automatic stop.
Prefer batches; finite targeted worklists are allowed when batch is unavailable
and semantics match. Discovery/result reads/paging are separate work, with their
actual cost still considered. Bound open-ended breadth. No retry/fanout storms.
Complete rows/checks do not certify final text. See interactive-planning.md.

Capture labels use returned America/Los_Angeles; actual PST/PDT+offset only with
trusted instant evidence. Date pinning is not a transaction. Compare only common
same-scope semantic fields, not projection shape or capture timestamps. Error
classification and delivery checks live in completion-contract.md.
