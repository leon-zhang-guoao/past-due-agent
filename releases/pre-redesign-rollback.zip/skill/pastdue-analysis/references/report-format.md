# Report format — compositions and module assembly

Read before every triggered daily or historical drilldown. User-facing reports
use the **same language as the user request** (English request → English
headings/prose/status labels; Chinese request → Chinese). Chinese labels in
examples are not defaults — translate section titles and status phrases to
match the request. Exact dates, row identities and statuses are mandatory;
prose may adapt without dropping required sections.

**Table columns, column order, and cell display formats** are defined only in
`references/table-display-contract.md` (Agent) and
`references/table-display-contract.edn` (machine source of truth). Do not
invent alternate headers or show raw ratios where the contract requires
percentages / `pp` / `YYYY-MM-DD`.

## Template-first gate (before any analytic report)

Use this lookup order whenever the user wants monitoring, review, drilldown,
or any structured analysis output — including **no-trigger** daily runs with
only Country metrics. It is a resolution workflow, not a fixed script for
every sentence.

1. **Pick composition** — Read `references/table-display-contract.edn`
   `:compositions` (or the cheat sheet in `table-display-contract.md`):
   `daily_full`, `historical_full`, `historical_events_only`, or a standalone
   module when the ask is narrow (one Country table, one Vendor’s ETA, etc.).
2. **For each table block** — Find the module in `:modules` (same file + the
   matching `## module: <id>` section in the markdown guide). Render:
   - Section title from `:section-label` in the request language.
   - Optional trace: append `（module: <id>）` / `(module: <id>)` once per
     section (recommended for acceptance; omit only if the host forbids meta).
   - Columns in exact `:columns` / `fields` order; cell values per `:format`.
   - Status/classification cells use contract codes (e.g. `NORMAL`,
     `TRIGGERED`, `ZERO_BASELINE_INCREASE`) unless the module defines
     localized `:status` labels in the contract.
3. **No matching module** — Do not invent a “standard” table. Use prose (or a
   clearly labeled ad-hoc list) and state **无显示契约模板** /
   **no display-contract module** for that block.
4. **Prose is free** — Conclusions, 变化解读, limitations, run metadata
   (mode, threshold, run date) may vary in wording and order. Prose must not
   replace a contracted table with a reordered or re-columned substitute.

If composition and module both exist, the contracted table wins over stylistic
preference (thousands separators, extra columns, splitting ratio pairs, etc.).

## Report envelope

Daily: `PastDue Daily Monitor — <actual comparison dates> — UTC`.
Composition: `daily_full`. Always show US/CA via module `country_metrics`,
including normal and unavailable Countries. For each triggered Country assemble
`vendor_summary` (with compact ETA Code/Source change lists). Do **not** expand
per-Vendor detail tables by default. End with coverage/limitations and a short
driver note; cross-Country summary without mixing Vendor rankings.

Historical: `PastDue Historical Review — <inclusive start> to <end> — UTC`.
Composition: `historical_full` (or `historical_events_only` when the user asks
for the event index without drilldown). Show resolved dates, threshold (and
explicit request override if any), Countries, and module `trigger_events` with
exact target/previous dates and gap. State selected deep-dives (latest event
per Country by default; explicit all-event requests max 5/Country). Default
display per selected event: `vendor_summary` with compact ETA change lists.

## Module assembly (Country / event) — default display

1. **Trigger and dates** (prose identity for the Country/event): Country,
   target/previous UTC dates, actual gap, ratios, relative growth, point
   change, threshold — values formatted per the display contract. Say
   “较前一天” only for gap=1; otherwise “较上一可用快照变化”.
2. **`vendor_summary`**: select strictly positive Country-contribution deltas
   in descending order, ties by Vendor Code ascending. Display exactly 10 if
   at least 10 are available, otherwise the actual number. Never pad with
   nonpositive Vendors or stop at 80%. Use the **full** module column set,
   including `eta_code_changes_brief` and `eta_source_changes_brief`.
3. **Query (not default full tables):** Execution Kernel capabilities
   `:eta-code-changes` then `:eta-source-changes` (**separate** EQL; shared
   worklist + concurrency per `:execution-plane`). From each `OK` collection,
   sort abs(count Δ) DESC, target count DESC, ETA value ASC;
   take up to 5 buckets; format `signed_bucket_list` cells as
   `SH +290；NR +122；US +25` (zh joiner `；`). If remainder exists and the
   collection is complete/reconciled, append `其他 {signed_net}`. Source
   values must be `eta-source` strings (e.g. `EDI3A4C +14`), never Code codes.
4. **Coverage + brief prose**: sum selected positive shares (“Top N 覆盖全部正向贡献的 X%”);
   optionally 1–3 sentences on notable drivers (prefer Vendors with both
   dimensions `OK`, especially Tier A ranks). Not share of net Country growth.
   Disclose incomplete ETA via `analysis_status` / failure codes and `—`.

### Partial vs coverage-unknown

| Signal | Report effect |
|---|---|
| `collection-coverage-unknown` / `source-completeness: unknown` | At most one generic Limitations caveat. **Not** alone “部分完成”. |
| Worklist `BULKHEAD` / `HANDLE_*` / `UNREACHABLE` / `SOURCE_ERROR` | That capability item: `—` + status code; run may be Partial. |
| `HOST_PARTIAL` | Partial; name unfinished worklist items. |

Do not blur these into a single “Atlas unstable” sentence.

### Evidence tiers (pressure / timeout / long output)

| Tier | What | Under pressure |
|---|---|---|
| Attribution core | Worklist Code+Source per selected Vendor; fill brief list columns | Drain Tier A then Tier B **in this response** (or mark classified fail); never defer to next turn |
| Default display | `country_metrics` + `vendor_summary` + short prose | Do not dump full ETA module tables |
| On-demand | `vendor_metrics`, `eta_*_changes`, owners, notification, PO lines, **org mapping** | Explicit ask or org-slice / concentration question (R1) |

Forbidden: inventing bucket lists without querying changes; putting Code
values in Source columns; expanding all Top-10 full ETA tables in the default
report; substituting PO-line ETA for `eta_*-changes`; deferring remaining
Top-10 ETA to a later turn (`下轮继续` / voluntary `未查询`); combining
Code+Source (or metrics+mapping+PO) in one EQL; auto-querying Top-10
`master-mappings` on every default daily run (R1).

### Interactive Q&A composition

Interactive answers may assemble multiple modules from a Fact Plan (e.g.
Vendor metrics table + org mapping + PO line detail). Always label **current
context** modules when mixed with historical attribution. Prefer contracted
modules when they fit; otherwise prose + small tables using the same cell
formats.

## Organization analysis assembly (R1)

Org mapping is a first-class pipe (enrich / filter / rollup), not an Owner-only
fix. Default daily/historical summary does **not** auto-fetch mapping for
Top-10. Assemble when the user asks about department, DNA Primary/Manager,
concentration, Metabase-style vendor filters, or explicit enrich.

| Question shape | Atlas | Display |
|---|---|---|
| Enrich Vendor(s) | `master-mappings` | module `vendor_master_mapping` (+ banner 当前上下文) |
| Filter Vendors | `matching-mappings` (empty string = no filter on that dimension) | mapping module rows or prose + vendor list |
| Concentration | `vendor-master-mapping-rollups` | compact table or prose with counts |
| Cross with Top-10 | optional after attribution | state share of positive contribution under a Primary/Manager — still **current org**, not historical cause |

Never use detail-view `department_type` / `master_*` as mapping truth. Owner
module when asked: BUYER from detail; PRIMARY/MANAGER from mapping.

## On-demand Vendor detail (explicit ask)

When the user asks to expand a Vendor, ETA Code/Source tables, metrics, owners,
recipients, PO lines, or org mapping — render **only** the matching modules.
Heading when useful:
`#<rank> <Vendor Code> — <name> — <Country> — <previous> → <target>`.

1. **`vendor_metrics`**: key-value field order from the display contract.
2. **`eta_code_changes`**: Top-5 + Other when allowed, totals after the table,
   reconciliation and retrieval status.
3. **`eta_source_changes`**: same column structure, independently computed.
4. **变化解读** (prose): quantify largest increases/improvements; no PO
   migration inference; no blaming historical Owners.
5. **`vendor_master_mapping` / `current_owners` / `notification_recipients` /
   `current_po_lines`**: only when asked (or notification when the user wants
   routing). Caps for PO: 5/Vendor, 20/Country. Banner “当前上下文” for
   current facts.

ETA selection for **displayed** full tables (unchanged): complete changes
collection; sort abs(count delta) DESC, target count DESC, ETA value ASC;
Top-5 + Other when complete and reconciled; totals from all rows; Code and
Source never added together.

Zero baseline relative change: previous=0 and target>0 → zero-baseline label;
both zero → no-change label; Previous>0 and target=0 → `−100.00%`.

## Standalone / passive questions

When the user asks for a single capability (Country table only, event list,
one Vendor's ETA, owners, PO lines, recipients, etc.), render **only** the
matching module(s) from `table-display-contract`. Column order and formats
must be identical to the same module inside a full composition. Do not drop
columns for brevity; row count may be smaller when the ask is narrower.

An explicit positive-only ETA question may use legacy drivers and the legacy
80%/max-5 rule, labeled positive-only; those rows cannot supply full-change
totals or Other and are outside the default module full-change contract.

## Completeness ledger and partial output

Maintain a worklist keyed by Country + target date + previous date + Vendor
Code, with Code/Source query status (for brief list cells). Detail-module and
Owner/PO state only when those modules are in scope. States: complete, empty,
unavailable, incomplete, inconsistent, not queried. Aggregate labels: 完成 /
complete, 部分完成 / partial, 不可用 / unavailable. Unrequested detail modules
do not make attribution partial if brief ETA cells are filled or explicitly
failed.

**Daily triggered drilldown (single response):** after selecting Top-10, call
Atlas for **every** selected Vendor’s ETA Code then ETA Source to fill brief
list cells (and reconcile) **before** recommendations or closing the report.
Default report stops at `vendor_summary` + brief prose — do not render full
ETA/metrics/Owner/PO tables unless asked. Do not close by listing “priority
Vendors to check ETA”, “下轮继续”, or a planned follow-up worklist instead of
querying Code/Source now. `not queried` / `未查询` for ETA on a selected
Vendor is invalid when Atlas is reachable and the host has not hard-killed
the turn. After Atlas fail (one corrected retry) use explicit fail
placeholders on that Vendor and continue remaining Vendors in the **same**
response. If the host hard-kills mid-flight, label 部分完成 / partial and name
unfinished Country+Vendor+collection items — that is interruption, not an
allowed multi-turn ETA plan.

Before claiming 完成 (default summary report):

- `vendor_summary` has the selected Top-N Vendors in rank order with
  `eta_code_changes_brief` / `eta_source_changes_brief` filled from queried
  changes (Top-5 style lists), or explicit fail placeholders.
- Both ETA dimensions were queried per Vendor (or failure recorded); do not
  invent bucket lists. Source brief must not repeat Code codes.
- Each fact matches Country/Vendor and exact target/previous dates.
- When a dimension is complete, previous/target counts (and contributions at
  1e-9 tolerance) reconcile to Vendor facts; use that for status, even if full
  ETA tables are not rendered.
- No unknown pagination/spill on the queried collections used for primaries.

When rendering on-demand full ETA tables, also require Top-5/Other rules,
totals, and the same reconciliation before claiming that dimension complete.

For incomplete, mismatched or unreconciled collections, label the dimension
and show only trustworthy individual facts if useful; no Other row, full
totals or complete ranking claim. Continue the independent dimension, other
Vendors and other Countries; stop only conclusions dependent on the failed
data. At most one corrected retry per logical query (full identity +
collection); paging is not a retry and cannot reset the error budget.

When `current_po_lines` is explicitly requested, allocation stays max
5/Vendor and 20/Country, one candidate per Vendor first then fill by Vendor
contribution rank. For multiple historical events, apply the Country cap
across that on-demand ask, reuse current context for repeated Country/Vendor
pairs, and do not duplicate the same current PO to evade caps. Distinguish
“无匹配行”, “查询失败”, “未查询当前上下文” and “因 Country 展示上限未展示”.

If **rendered** output length forces a split **after** all brief ETA queries
are done, continue with labeled Country/event/Vendor ranges. Repeat full
module headers on continuations. Never replace unrendered Vendors with
“其余类似”. Do **not** split in order to postpone ETA queries — attribution
core must already be queried. If the host hard-kills before those queries
finish, report delivery incomplete and identify unfinished Vendors (not a
planned “下轮继续” workflow).

## Evidence and presentation

Discovery success is not evidence of trigger events. Unknown/unreachable
results → “尚无法确认”; successful complete empty event collection →
“在可比较快照中未发现触发”, with coverage caveats. Keep independent Country
outcomes.

All numeric/date cell formatting follows `table-display-contract` (percentages
with two decimals, contributions as `pp`, counts as integers, dates as
`YYYY-MM-DD`). Preserve UNKNOWN and UNASSIGNED. Do not show infinity.
