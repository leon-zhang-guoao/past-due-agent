# Table display contract — modular templates

Machine source of truth: `table-display-contract.edn`. This file is the
Agent-facing fill guide. **EDN wins on conflict.** Keep every fenced
`fields` block identical to the EDN module column `:id` order.

## Template-first gate

Before writing tables in any analytic report:

1. Resolve **composition** from `:compositions` below (or a single
   `:standalone? true` module when the user asks one thing).
2. For each table, resolve **module** under `:modules` and the `## module:`
   section in this file. Output that module’s `fields` order and `:format`
   rules. Section title = `:section-label` (request language); optional
   `（module: <id>）` on the heading.
3. **No module** → prose only for that content; say there is no display
   contract for that block.
4. **Prose** (结论, limits, interpretation) is not templated; do not use prose
   tables to bypass step 2 when a module exists.

## How to choose what to render

1. **Full daily report** → composition `daily_full`.
2. **Full historical review** → composition `historical_full`.
3. **Historical event list only** → composition `historical_events_only`.
4. **User asks one capability** → render only that module (or few modules).
   Column order and cell formats MUST match the same module inside a full
   report. Never invent a shorter ad-hoc header.

**Default full compositions** render Country metrics + `vendor_summary` only
(with compact Code/Source change lists). They do **not** expand
per-Vendor detail tables by default.

**Evidence tiers (not a rigid call script):**

- **Attribution core (default display):** `vendor_summary` with compact
  `eta_code_changes_brief` / `eta_source_changes_brief` cells (multi-bucket
  lists from queried `eta-*-changes`). Brief prose coverage OK.
- **Query still required:** for each selected Vendor, call Code then Source
  changes to build those brief cells and reconcile; do not invent buckets.
- **On-demand modules:** `vendor_metrics`, `eta_code_changes`,
  `eta_source_changes`, `vendor_master_mapping`, `current_owners`, `notification_recipients`,
  `current_po_lines` — only when the user explicitly asks (one Vendor, expand
  ETA, owners, PO lines, etc.). Same column contracts when rendered.

Never present current PO-line ETA values as historical `eta_*-changes`.
Never put Code values in Source columns (MCP `eta-source` returns Source names).

## Composition cheat sheet

| composition | Modules |
|---|---|
| `daily_full` | always `country_metrics`; per triggered Country `vendor_summary` (+ Code/Source brief lists); on-demand detail modules |
| `historical_full` | always `trigger_events`; per selected event `vendor_summary` (+ Code/Source brief lists); on-demand detail modules |
| `historical_events_only` | always `trigger_events` |

## Hard display rules

Keep Atlas/computation values unrounded. Format only when writing cells.

| Kind | format | Must show | Forbidden |
|---|---|---|---|
| Ratios / relative / share | `ratio_pct` / `relative_pct` / `share_pct` | `12.34%` | `0.1234`, uneven decimals |
| Contribution / point change | `pp` | `+1.50 pp` | `0.015`, `%`, missing sign/space |
| Contribution pair | `pair_pp` | `1.00 pp→2.50 pp` | raw ratios |
| Snapshot dates | `date` | `YYYY-MM-DD` | `/`, month names, unpadded |
| Counts / IDs / rank | `int` | `1234` | thousands separators, `.0` |
| Net change | `signed_int` | `+12` / `−5` / `0` | unsigned positives, ASCII `-` |
| ETA brief list | `signed_bucket_list` | `SH +290；NR +122` | one bucket only when more exist; Code in Source column |
| Count pair | `pair_count` | `10→18` | `->`, `-` |
| Ratio pair | `pair_ratio` | `8.00%→10.00%` | `0.08→0.10` |
| Gap | `gap_days` | `1d` | bare `1` |
| Bool | `bool` | `是`/`否` or `Yes`/`No` | `true`/`false` |
| Empty / fail / skip | placeholders | `—` / `不可用`\|`unavailable` / `未查询`\|`not queried` (attribution-core ETA: not for voluntary skip / “下轮继续”) | fake `0` / `N/A` |

Relative null: zero-baseline up / no change labels; never `Infinity` / `NaN`.
Trigger classification uses unrounded values only.

Labels follow request language (`label.zh` / `label.en`). `field_id` order
never changes with language.

---

## module: country_metrics

```fields
country_code
status
latest_date
previous_date
gap_days
past_due_pair
open_pair
ratio_pair
relative_change
point_change
```

Example header (zh): `Country | 状态 | 本期日期 | 上期日期 | 间隔 | 逾期行数 上期→本期 | Open 上期→本期 | 逾期率 上期→本期 | 相对变化 | 百分点变化`

Example row: `US | TRIGGERED | 2026-08-17 | 2026-08-16 | 1d | 100→120 | 1000→1100 | 10.00%→10.91% | 9.10% | +0.91 pp`

---

## module: trigger_events

```fields
country_code
target_date
previous_date
gap_days
past_due_pair
open_pair
ratio_pair
relative_change
point_change
trigger_type
selected_for_drilldown
```

---

## module: vendor_summary

```fields
rank
vendor_code
vendor_name
past_due_pair
past_due_net
open_pair
vendor_ratio_pair
country_contrib_delta
positive_share
eta_code_changes_brief
eta_source_changes_brief
analysis_status
```

Daily `latest-*` and historical `target-*` map into the same field_ids.
Fewer rows (e.g. Top-3 ask) still use this full column set.

**Brief ETA cells (`signed_bucket_list`):** from each Vendor’s complete
`eta-*-changes`, sort by abs(count Δ) DESC, target count DESC, ETA value ASC;
take up to 5 buckets; format each as `{value} {signed_net}`; join with `；`
(zh) or `; ` (en). Example: `SH +290；NR +122；US +25`. If more buckets remain
and the collection is complete/reconciled, append `其他 {signed_net}` /
`Other {signed_net}` for the remainder’s net count change. Prefer listing
non-zero nets; include material zeros only when needed for clarity. On
failed/incomplete dimension: `—` / `不可用` and set `analysis_status`.
Source brief must use `eta-source` names (e.g. `EDI3A4C +14`), never Code codes.

---

## module: vendor_metrics

**On-demand** in default full reports (user asks for one Vendor’s metrics).

Layout: key-value rows in this exact field order (metric label | formatted value).

```fields
past_due_pair
past_due_net
open_pair
open_net
vendor_ratio_pair
vendor_ratio_point_change
country_contrib_pair
country_contrib_delta
```

`country_contrib_pair` uses `pair_pp` (e.g. `1.00 pp→2.50 pp`).

---

## module: eta_code_changes

**On-demand** in default full reports (user asks to expand a Vendor’s ETA Code).
Still queried in the background to fill `vendor_summary` `eta_code_changes_brief`.

```fields
eta_value
previous_count
target_count
net_change
relative_change
country_contrib_delta
```

After the table, always print totals with `signed_int`: increase total, decrease
total, net change. Other row label: `其他（N 项）` / `Other (N)` when derived
aggregate is allowed (complete + reconciled). Top-5 + Other selection rules
remain in `report-format.md` / policy.

---

## module: eta_source_changes

**On-demand** in default full reports (user asks to expand a Vendor’s ETA Source).
Still queried in the background to fill `vendor_summary` `eta_source_changes_brief`.

Same columns and formats as `eta_code_changes` (`columns-ref` in EDN). Only the
ETA value attribute namespace differs (eta-source).

```fields
eta_value
previous_count
target_count
net_change
relative_change
country_contrib_delta
```

---

## module: vendor_master_mapping

On-demand / standalone (R1). Current DNA org rows from
`vendor_master_mapping_view` (department / primary / manager). Not historical
causation. Do not substitute detail-view `master_*` columns.

```fields
department_type
master_primary
master_manager
```

## module: current_owners

**On-demand** in default full reports (user asks for owners / current action).

Banner: `当前上下文` / `Current context`. Role display order forced:
BUYER → PRIMARY → MANAGER.

```fields
owner_role
owner_display
risk_line_count
past_due_line_count
```

---

## module: current_po_lines

**On-demand only** — not part of default `daily_full` / `historical_full`.
Use when the user explicitly asks for high-risk / past-due PO lines.
Banner: `当前上下文` / `Current context`. Primary/Manager stay in
`current_owners` only.

```fields
order_type
po_number
po_line_number
sku_number
risk_level
is_past_due
past_due_days
eta_code
eta_source
buyer_owner
```

---

## module: notification_recipients

```fields
routing_bucket
contact_group
email
contact_name
routing_rule
selection_status
```

`routing_bucket` is `TO`/`CC`. `contact_group` is
`VENDOR`/`EMT`/`WAREHOUSE`/`BUYER`. Display only — do not send email.

---

## Agent checklist

1. Load this contract (and EDN when validating offline) before rendering tables.
2. Do not add, drop, or reorder columns inside a module.
3. Map raw facts → field_id → format_id → cell text.
4. Split continuations must repeat the full module header.
5. Passive interpretation stays prose (report-format); it is not a table module.
