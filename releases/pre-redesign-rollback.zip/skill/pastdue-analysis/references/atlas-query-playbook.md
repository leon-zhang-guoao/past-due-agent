# Atlas query playbook

**Enforcement:** PastDue Kernel Runtime (`runtime/pastdue_kernel`) + Preflight
Gate + `policy.edn` `:execution-plane` / `:disambiguation`. This playbook is the
**capability dictionary and recovery guide** for operators — not a second
concurrency policy and not permission to guess roots.

Runtime schema comes only from the connected Open Atlas MCP tools. Do not cite
or open chart/EDN filenames for attribute discovery.

## Discovery

On first use (and after any mismatch), call MCP in this order:

1. `list_entities` — entities and `:identity_keys` this token grants.
2. `list_attributes` on the entities you will query — exact join names,
   `required_inputs`, `order.allowed` / defaults.
3. `search_attributes` when you know a human term but not the attribute path.

Treat `data-contract.md` as a checklist to verify, not as live schema. Atlas
auto-navigates declared graph paths; do not invent joins or identity aliases.

`execute_eql` receives an EDN map:

```clojure
{:entity <identity-map>
 :query <EQL-vector>}
```

Use `{}` only for root collections whose resolver has no required inputs. A plain join `{:collection [:field]}` is valid EQL. To attach paging/sorting, examples use `({:collection [:field]} {:limit 367})`. Parameters are optional; they cannot replace required values in `:entity`. Do not place a parameter map where the join's child projection vector belongs.

Use the installed tool's input schema to wrap this EDN (for example, an EDN string in its `query` argument). Do not confuse that tool argument with the inner EQL `:query` vector.

## Relative dates and request scope

Establish current UTC date D from trusted runtime date/time or an available clock tool on each new relative-date request. Use the time source only for dates; business facts still come exclusively from Atlas. Never derive today from the latest snapshot, template dates, or old chat messages. If the UTC anchor is unavailable, ask only for the anchor, not for confirmation of an otherwise deterministic range.

| Request | Inclusive UTC target-date range |
|---|---|
| 过去一周 / 最近7天 / past week | D−7 through D−1 |
| 过去 N 天 / past N days | D−N through D−1 (positive integer N) |
| 上周 / previous calendar week | Monday through Sunday of the preceding UTC calendar week |
| 昨天 / yesterday | D−1 through D−1 |
| Explicit single date | That date for both endpoints |
| Explicit start/end | Preserve endpoints; disclose that only dates before D are completed |

State the resolved range and execute; no extra approval is needed. A wholly incomplete/future range has no eligible target dates; report that limitation, not “no triggers”. Reject reversed ranges and ask to narrow ranges exceeding 366 inclusive dates rather than silently truncating them. Do not silently substitute a different year. For ambiguous “recently”, ask for a range; the deterministic phrases above do not need clarification.

Example with injected D=2026-09-18: past week is 2026-09-11 through 2026-09-17. This is a test example, never a production clock value.

Use requested Countries (default policy allowlist US/CA), one request per Country. Daily scheduling keeps the configured monitoring scope. Read threshold from policy (default 0.10); for explicit historical what-if requests, e.g. 15%, use 0.15 and label the override without changing policy or scheduled runs. Ask if a requested threshold's meaning is ambiguous.

## Historical preflight and extension

For **both** `trigger-events` and `comparisons`, provide these four keys in `:entity`:

| Namespace: `pastdue.country-history-query` | Value |
|---|---|
| `country-code` | One requested Country string |
| `range-start-date` | Resolved ISO date |
| `range-end-date` | Resolved ISO date |
| `relative-change-threshold` | Numeric fraction, normally 0.10 |

`comparisons` uses the threshold to calculate `trigger-type` even though it does not filter out normal dates. Keep its threshold input. An empty entity or threshold alone cannot reach either collection. There is no declared `pastdue.country-history-query/all` entry in this bundle.

Before execution, check all four inputs together, inclusive date limits, exact field names, and requested collection. Use historical `target-past-due-ratio` and `trigger-type`; `latest-past-due-ratio` belongs to the daily monitor namespace, and `change-classification` is not a declared historical attribute. A search result is a partial discovery result, not the entire schema.

Templates are a reliable starting point, not a closed whitelist. Additional projections or collections are allowed after `list_attributes` confirms exact names and required inputs. Use `data-contract.md` only as a checklist against MCP. Refresh discovery after a deployment mismatch. Preserve the three event identity fields for downstream attribution. Do not construct previous dates from target−1; use the returned pair.

### Sorting (`order_by`) — discovery-driven

Do **not** invent sort keys and do **not** treat SQL/`field_mapping` column names
(e.g. `country_code`, `contribution_rank`) as the EQL `order_by` contract.
Deployments differ (Atlas may validate against attribute names in
`:order` / `:sort :allowed`).

1. Prefer **omitting** `:order_by` and `:sort_dir` so the resolver **default**
   sort from discovery applies. Runnable examples below omit them on purpose.
2. When a non-default sort is required, copy the value from that collection’s
   discovery metadata (`order.allowed` / `:sort :allowed`) for the **current**
   environment — usually a namespaced attribute such as
   `pastdue.country-monitor/country-code`. Never assume a snake_case alias.
3. On `order-not-allowed` / `engine.request/order-not-allowed`: drop the bad
   `order_by` or replace it from discovery `:allowed`, then retry once. Do not
   burn the retry guessing column names.
4. Templates may mention intended ranking in prose (Top-10 by contribution rank,
   ETA paging by code/source). That intent is for Agent-side ranking when needed;
   it is not a license to hardcode unvalidated `order_by` strings.

## Daily monitor

Query the root Country collection, then retain US/CA in Agent policy:

```clojure
{:entity {}
 :query
 [({:pastdue.country-monitor/all
    [:pastdue.country-monitor/country-code
     :pastdue.country-monitor/latest-snapshot-date
     :pastdue.country-monitor/previous-snapshot-date
     :pastdue.country-monitor/snapshot-gap-days
     :pastdue.country-monitor/latest-snapshot-age-days
     :pastdue.country-monitor/latest-past-due-count
     :pastdue.country-monitor/previous-past-due-count
     :pastdue.country-monitor/latest-open-count
     :pastdue.country-monitor/previous-open-count
     :pastdue.country-monitor/latest-past-due-ratio
     :pastdue.country-monitor/previous-past-due-ratio
     :pastdue.country-monitor/relative-ratio-change
     :pastdue.country-monitor/percentage-point-change
     :pastdue.country-monitor/zero-baseline-increase
     :pastdue.country-monitor/has-comparable-snapshots]}
   {:limit 100})]}
```

For each triggered Country, query `positive-vendor-contributors` by `pastdue.country-monitor/country-code`, request the first 10 ranked positive rows (resolver default is usually contribution rank ascending; confirm via discovery), and retain all 10 or all available if fewer. Never stop at 80%. Check paging/limits if fewer than 10 are returned; coverage uses resolver shares over all positive Vendors. Use `vendor-changes` only for reconciliation/improvement questions. Pin the Country dates before ETA queries: map the daily Vendor latest date to the historical target date, verify all Vendor dates match the Country, and use the explicit-pair changes templates below. If daily Vendor dates differ, correct once using historical Vendor contributors for the original Country pair and rebuild that Country selection. Current Owner/PO remain Country+Vendor queries.

### Daily Vendor Top-10 facts

Use the triggered Country, not the illustrative US value. Request all facts needed for the fixed summary and ETA reconciliation:

```clojure
{:entity {:pastdue.country-monitor/country-code "US"}
 :query
 [({:pastdue.country-monitor/positive-vendor-contributors
    [:pastdue.vendor-contribution/country-code
     :pastdue.vendor-contribution/vendor-code
     :pastdue.vendor-contribution/vendor-name
     :pastdue.vendor-contribution/latest-snapshot-date
     :pastdue.vendor-contribution/previous-snapshot-date
     :pastdue.vendor-contribution/latest-past-due-count
     :pastdue.vendor-contribution/previous-past-due-count
     :pastdue.vendor-contribution/past-due-count-change
     :pastdue.vendor-contribution/latest-open-count
     :pastdue.vendor-contribution/previous-open-count
     :pastdue.vendor-contribution/open-count-change
     :pastdue.vendor-contribution/latest-vendor-ratio
     :pastdue.vendor-contribution/previous-vendor-ratio
     :pastdue.vendor-contribution/vendor-ratio-change
     :pastdue.vendor-contribution/latest-country-contribution
     :pastdue.vendor-contribution/previous-country-contribution
     :pastdue.vendor-contribution/delta-country-contribution
     :pastdue.vendor-contribution/positive-contribution-share
     :pastdue.vendor-contribution/cumulative-positive-share
     :pastdue.vendor-contribution/contribution-rank]}
   {:limit 10})]}
```

Inspect rank and metadata; if a deployment returns fewer than ten due to an internal cap, fetch the continuation before claiming fewer positives exist. Dates must match the already retrieved Country pair. If rows are not contribution-rank ordered, re-sort in the Agent using `contribution-rank` or set `order_by` only from discovery `:allowed`.

## Historical trigger scan

Run separately for US and CA. Example inclusive UTC range 2026-08-01 through 2026-08-18:

```clojure
{:entity
 {:pastdue.country-history-query/country-code "US"
  :pastdue.country-history-query/range-start-date "2026-08-01"
  :pastdue.country-history-query/range-end-date "2026-08-18"
  :pastdue.country-history-query/relative-change-threshold 0.10}
 :query
 [({:pastdue.country-history-query/trigger-events
   [:pastdue.country-trigger-event/country-code
    :pastdue.country-trigger-event/target-snapshot-date
    :pastdue.country-trigger-event/previous-snapshot-date
    :pastdue.country-trigger-event/snapshot-gap-days
    :pastdue.country-trigger-event/target-past-due-count
    :pastdue.country-trigger-event/previous-past-due-count
    :pastdue.country-trigger-event/target-open-count
    :pastdue.country-trigger-event/previous-open-count
    :pastdue.country-trigger-event/target-past-due-ratio
    :pastdue.country-trigger-event/previous-past-due-ratio
    :pastdue.country-trigger-event/relative-ratio-change
    :pastdue.country-trigger-event/percentage-point-change
    :pastdue.country-trigger-event/zero-baseline-increase
    :pastdue.country-trigger-event/trigger-type]}
   {:limit 367})]}
```

Default discovery sort is typically newest target date first; if not, sort in the
Agent by `target-snapshot-date` or apply an `order_by` taken from `:allowed`.

A single requested target date uses the same date for range start and end. The resolver still finds the nearest available snapshot before that date, including one before range start.

Use `comparisons` rather than `trigger-events` when the user wants every comparable date, including dates below threshold. Replace only the collection name in the template; retain all four entity inputs and the event projection.

List all returned trigger events after checking completeness. Default selected deep-dive is the newest event per Country; explicit event-list-only requests stop at the index. If the user explicitly requests every event's attribution, select at most the newest 5 per Country.

## Historical Vendor attribution

Use the exact identity returned by the trigger scan. Never guess a previous date.

```clojure
{:entity
 {:pastdue.country-trigger-event/country-code "US"
  :pastdue.country-trigger-event/target-snapshot-date "2026-08-17"
  :pastdue.country-trigger-event/previous-snapshot-date "2026-08-16"}
 :query
 [({:pastdue.country-trigger-event/positive-vendor-contributors
   [:pastdue.historical-vendor-contribution/country-code
    :pastdue.historical-vendor-contribution/vendor-code
    :pastdue.historical-vendor-contribution/vendor-name
    :pastdue.historical-vendor-contribution/target-snapshot-date
    :pastdue.historical-vendor-contribution/previous-snapshot-date
    :pastdue.historical-vendor-contribution/target-past-due-count
    :pastdue.historical-vendor-contribution/previous-past-due-count
    :pastdue.historical-vendor-contribution/past-due-count-change
    :pastdue.historical-vendor-contribution/target-open-count
    :pastdue.historical-vendor-contribution/previous-open-count
    :pastdue.historical-vendor-contribution/open-count-change
    :pastdue.historical-vendor-contribution/target-vendor-ratio
    :pastdue.historical-vendor-contribution/previous-vendor-ratio
    :pastdue.historical-vendor-contribution/vendor-ratio-change
    :pastdue.historical-vendor-contribution/target-country-contribution
    :pastdue.historical-vendor-contribution/previous-country-contribution
    :pastdue.historical-vendor-contribution/delta-country-contribution
    :pastdue.historical-vendor-contribution/positive-contribution-share
    :pastdue.historical-vendor-contribution/cumulative-positive-share
    :pastdue.historical-vendor-contribution/contribution-rank]}
   {:limit 10})]}
```

Use `pastdue.country-trigger-event/vendor-changes` for full reconciliation or negative offsets.

## Default ETA changes — daily and historical

### Per-Vendor path (current UAT graph — default drilldown)

Current UAT MCP exposes all-change ETA on
`pastdue.historical-vendor-contribution` as `eta-code-changes` and
`eta-source-changes`. Confirm with `list_attributes` before calling. There is
no Country-pair batch ETA join on `country-trigger-event` in this environment;
do not require or invent one.

After the positive Top-10 Vendor set is known, run capabilities
`:eta-code-changes` then `:eta-source-changes` through the **Universal
Execution Kernel** (policy `:execution-plane`). Do not invent a Country-batch
ETA join.

## Universal Execution Kernel (all Atlas factual calls)

Applies to **every** capability in `:execution-plane :capabilities`, including
ones added later. New scenario = declare a capability (or prove a reachable
path via MCP). Do **not** invent a separate concurrency policy per ask.

### Kernel contract (hard)

1. **Reachability first:** use a declared `:entry` (or discovery-proven join).
   Empty `search_attributes` + no matching capability → unknown / contract gap
   (`UNREACHABLE` if a guessed path fails). **Forbidden:** inventing a root
   entity projection when nothing points at those attributes.
2. **Single-collection EQL:** at most one join/collection per `execute_eql`.
3. **Worklist:** key =
   `(capability-id, country?, vendor?, collection, identity…)`. States:
   `pending` → `in_flight` → `ok` | `failed_retryable` → (≤1 corrected retry)
   → `ok` | `failed_final`. Never re-issue terminal states.
4. **Handle ownership:** `analyze_result` only on that item’s handle. Reject
   stale/unrelated/wrong-schema handles (`HANDLE_MISMATCH` /
   `HANDLE_EXPIRED`).
5. **Shared concurrency budget** for all capabilities with
   `:shares-global-budget true` (ETA + org + Owner + PO + notification, …).
   Start at `:concurrency-start` (2); on `bulkhead_rejected` degrade to 1;
   restore after `:bulkhead-recovery-successes` consecutive OK **across** the
   shared pool.
6. **Failure codes:** `OK`, `BULKHEAD`, `HANDLE_MISMATCH`, `HANDLE_EXPIRED`,
   `UNREACHABLE`, `SOURCE_ERROR`, `HOST_PARTIAL`.
   `collection-coverage-unknown` is **not** a failure.

### Kernel scheduler (soft)

1. Fan-out (`:fan-out :per-vendor`): enqueue by parent rank; Tier A
   (ranks 1…`:tier-a-ranks`) before Tier B when using tiered depth; default
   daily ETA obligation remains full Top-N when Atlas allows.
2. Pairing: for ETA, Code work items before Source (`:order-before`).
3. One item `failed_final` must not suppress siblings; keep `—` + code.
4. Interactive depth narrowing only on explicit user ask — never scheduled
   daily.

### Kernel anti-examples

- Combined Code+Source (or any two collections) in one `:query`.
- `analyze_result` on an unrelated/stale handle.
- Re-issuing a terminal worklist key.
- Unbounded parallel Top-N “to finish faster”.
- Guessing `pastdue.vendor-master-mapping` as EQL root for Specialist/enrich.
- Treating `collection-coverage-unknown` as Vendor/capability failure.
- Bypassing the kernel for a “new” ad-hoc Atlas pipe.

### Capability cheat-sheet (confirm names via MCP)

| Id | Allowed entry | Forbidden roots |
|---|---|---|
| `:eta-code-changes` / `:eta-source-changes` | `historical-vendor-contribution/eta-*-changes` | combining both |
| `:master-mappings` | `vendor-contribution/master-mappings` | `vendor-master-mapping` entity root |
| `:matching-mappings` | `vendor-master-mapping-query/matching-mappings` | mapping entity root |
| `:mapping-rollups` | `country-monitor/vendor-master-mapping-rollups` | — |
| `:owner-current-risks` | `vendor-contribution/current-owner-risks` | — |
| `:current-high-risk-lines` | `vendor-contribution/current-high-risk-lines` | — |
| `:notification-recipients` | `…/notification-recipients` + `recipient-type` | two-key entity without type |

Missing `eta-*-changes` join means deployment mismatch; do not fall back to
positive-only drivers and call them complete changes. Templates use
illustrative identities only:

### ETA Code (single Vendor)

```clojure
{:entity
 {:pastdue.historical-vendor-contribution/country-code "US"
  :pastdue.historical-vendor-contribution/vendor-code 12345
  :pastdue.historical-vendor-contribution/target-snapshot-date "2026-08-17"
  :pastdue.historical-vendor-contribution/previous-snapshot-date "2026-08-16"}
 :query
 [({:pastdue.historical-vendor-contribution/eta-code-changes
    [:pastdue.historical-vendor-eta-code/country-code
     :pastdue.historical-vendor-eta-code/vendor-code
     :pastdue.historical-vendor-eta-code/target-snapshot-date
     :pastdue.historical-vendor-eta-code/previous-snapshot-date
     :pastdue.historical-vendor-eta-code/eta-code
     :pastdue.historical-vendor-eta-code/target-past-due-count
     :pastdue.historical-vendor-eta-code/previous-past-due-count
     :pastdue.historical-vendor-eta-code/past-due-count-change
     :pastdue.historical-vendor-eta-code/target-country-contribution
     :pastdue.historical-vendor-eta-code/previous-country-contribution
     :pastdue.historical-vendor-eta-code/delta-country-contribution]}
   {:limit 100 :offset 0})]}
```

Do **not** request `past-due-count-relative-change` from Atlas. Compute it in the
Agent after rows return: `null` when previous count is 0; otherwise
`(target - previous) / previous`. Atlas no longer returns that column (JDBC
mapping of `Nullable(Float64)` caused `:source` failures).

### ETA Source (single Vendor)

```clojure
{:entity
 {:pastdue.historical-vendor-contribution/country-code "US"
  :pastdue.historical-vendor-contribution/vendor-code 12345
  :pastdue.historical-vendor-contribution/target-snapshot-date "2026-08-17"
  :pastdue.historical-vendor-contribution/previous-snapshot-date "2026-08-16"}
 :query
 [({:pastdue.historical-vendor-contribution/eta-source-changes
    [:pastdue.historical-vendor-eta-source/country-code
     :pastdue.historical-vendor-eta-source/vendor-code
     :pastdue.historical-vendor-eta-source/target-snapshot-date
     :pastdue.historical-vendor-eta-source/previous-snapshot-date
     :pastdue.historical-vendor-eta-source/eta-source
     :pastdue.historical-vendor-eta-source/target-past-due-count
     :pastdue.historical-vendor-eta-source/previous-past-due-count
     :pastdue.historical-vendor-eta-source/past-due-count-change
     :pastdue.historical-vendor-eta-source/target-country-contribution
     :pastdue.historical-vendor-eta-source/previous-country-contribution
     :pastdue.historical-vendor-eta-source/delta-country-contribution]}
   {:limit 100 :offset 0})]}
```

### Complete retrieval before Top-5 display

100 is a page size, not a display cap. Keep the full identity fixed; page with a
stable sort from discovery default/`order.allowed` (typically the ETA code or
ETA source attribute ascending — never invent `dimension_value`). Advance
`offset` by unique rows already consumed, respecting deployed collection/spill
metadata. Read spills using available Atlas tools, not invented commands. A short
page proves completion only when no error/truncation/cap/spill contradicts it;
with absent completion metadata, fetch the next offset until a successful empty
page. Detect duplicate identities, repeated pages/no progress and changing
snapshot data; do not loop indefinitely or silently deduplicate conflicting
values. If the deployment cannot deliver the remainder, mark incomplete.

After complete retrieval, check every Country/Vendor/date identity, reconcile each dimension independently with Vendor facts, then apply abs(count change) DESC, target count DESC, ETA value ASC in the Agent. The fetch order is solely stable pagination; it is not the display ranking. Render Top-5 + Other and signed totals as specified in report-format.md. Failed, incomplete or inconsistent dimensions must not have an Other row or full totals.

### Explicit positive-only questions (compatibility)

The original daily and historical `eta-code-drivers` / `eta-source-drivers` collections retain their positive Country-contribution filtering and share/rank fields. Use them only for explicit positive-attribution questions with the legacy 80%/max-5 rule. Do not request the new relative-count attribute from their projection, and never compute full-change totals from those collections. Default triggered reports always use the changes collections above.

## Fact dictionary — Vendor snapshot metrics (one Vendor)

**Forbidden:** starting on `pastdue.vendor-contribution` with country+vendor
and projecting scalars (`vendor-name`, `latest-*`, `previous-*`, ratios). That
is `UNREACHABLE` (no root resolver for those attributes).

**Allowed:** country-scoped contributors (or `vendor-changes`), then filter in
`analyze_result`:

```clojure
{:entity {:pastdue.country-monitor/country-code "CA"}
 :query
 [({:pastdue.country-monitor/positive-vendor-contributors
    [:pastdue.vendor-contribution/vendor-code
     :pastdue.vendor-contribution/vendor-name
     :pastdue.vendor-contribution/previous-snapshot-date
     :pastdue.vendor-contribution/latest-snapshot-date
     :pastdue.vendor-contribution/previous-past-due-count
     :pastdue.vendor-contribution/latest-past-due-count
     :pastdue.vendor-contribution/past-due-count-change
     :pastdue.vendor-contribution/previous-open-count
     :pastdue.vendor-contribution/latest-open-count
     :pastdue.vendor-contribution/previous-vendor-ratio
     :pastdue.vendor-contribution/latest-vendor-ratio]}
   {:limit 1000})]}
```

```sql
SELECT * FROM data WHERE vendor_code = 40979
```

Reuse an in-session Top-10 handle when it already contains that Vendor.

## Current Owner context (Kernel capability `:owner-current-risks`)

**Separate** from PO lines — one collection per `execute_eql`.

```clojure
{:entity
 {:pastdue.vendor-contribution/country-code "US"
  :pastdue.vendor-contribution/vendor-code 12345}
 :query
 [({:pastdue.vendor-contribution/current-owner-risks
    [:pastdue.owner-current-risk/owner-role
     :pastdue.owner-current-risk/owner-display
     :pastdue.owner-current-risk/current-risk-line-count
     :pastdue.owner-current-risk/current-past-due-line-count]}
   {:limit 100})]}
```

## Current PO / Past Due line detail (Kernel `:current-high-risk-lines`)

User “detail” / 每一行 → this capability. Current context only; limits per
`policy.edn` `:po-line-limits`.

```clojure
{:entity
 {:pastdue.vendor-contribution/country-code "CA"
  :pastdue.vendor-contribution/vendor-code 40979}
 :query
 [({:pastdue.vendor-contribution/current-high-risk-lines
    [:pastdue.current-high-risk-line/order-type
     :pastdue.current-high-risk-line/po-number
     :pastdue.current-high-risk-line/po-line-number
     :pastdue.current-high-risk-line/sku-number
     :pastdue.current-high-risk-line/risk-level
     :pastdue.current-high-risk-line/is-past-due
     :pastdue.current-high-risk-line/past-due-days
     :pastdue.current-high-risk-line/eta-code
     :pastdue.current-high-risk-line/eta-source
     :pastdue.current-high-risk-line/eta-date
     :pastdue.current-high-risk-line/buyer-owner
     :pastdue.current-high-risk-line/primary-owner
     :pastdue.current-high-risk-line/manager-owner]}
   {:limit 5
    :order_by "pastdue.current-high-risk-line/risk-priority-rank"
    :sort_dir "ASC"})]}
```

Label Owner and PO results **current / current-state**. Never state that
current assignment or current PO rows caused the historical Country/Vendor
event. Re-sort in the Agent by `owner-role` / `risk-priority-rank` when needed.

BUYER is from `past_due_detail_view.buyer_email`. PRIMARY/MANAGER are from
`past_due.vendor_master_mapping_view` via Atlas — never from detail-view
`master_primary` / `master_manager` / `department_type`.

**Anti-example:** one `:query` that mixes contribution scalars +
`master-mappings` + `current-high-risk-lines` (or Owner+PO together).

## Vendor master mapping (org context, multi-scenario)

Physical source: `past_due.vendor_master_mapping_view` (`country_code` +
`vendor_no`). Current organization only — not historical causation.

Run through Execution Kernel capability `:master-mappings` (or
`:matching-mappings` / `:mapping-rollups`). **Never** start
`execute_eql` with `:entity` on `pastdue.vendor-master-mapping` alone to
read primary/manager — that path is `UNREACHABLE` (no root resolver). For
“ETA Specialist”, query `:master-mappings` once per Vendor (worklist), then
filter rows where `department-type = ETAD` and take `master-primary`
(manager = `master-manager` on the same row). Share the global concurrency
budget with ETA/Owner fan-out.

### By Vendor (Top-10 enrichment / actionability)

```clojure
{:entity
 {:pastdue.vendor-contribution/country-code "CA"
  :pastdue.vendor-contribution/vendor-code 12345}
 :query
 [({:pastdue.vendor-contribution/master-mappings
   [:pastdue.vendor-master-mapping/department-type
    :pastdue.vendor-master-mapping/master-primary
    :pastdue.vendor-master-mapping/master-manager]}
   {:limit 50})]}
```

### Filter Vendors (Metabase-style; empty string = no filter)

```clojure
{:entity
 {:pastdue.vendor-master-mapping-query/country-code "CA"
  :pastdue.vendor-master-mapping-query/department-type-filter "ETAD"
  :pastdue.vendor-master-mapping-query/master-primary-filter ""
  :pastdue.vendor-master-mapping-query/master-manager-filter ""}
 :query
 [({:pastdue.vendor-master-mapping-query/matching-mappings
   [:pastdue.vendor-master-mapping/vendor-code
    :pastdue.vendor-master-mapping/department-type
    :pastdue.vendor-master-mapping/master-primary
    :pastdue.vendor-master-mapping/master-manager]}
   {:limit 200})]}
```

### Country rollups (concentration)

```clojure
{:entity {:pastdue.country-monitor/country-code "US"}
 :query
 [({:pastdue.country-monitor/vendor-master-mapping-rollups
   [:pastdue.vendor-master-mapping-rollup/department-type
    :pastdue.vendor-master-mapping-rollup/master-primary
    :pastdue.vendor-master-mapping-rollup/master-manager
    :pastdue.vendor-master-mapping-rollup/mapped-vendor-count]}
   {:limit 200})]}
```

## Notification recipients

Collection: `pastdue.vendor-contribution/notification-recipients`.  
Resolver inputs (all required in `:entity`): Country + Vendor Code +
`pastdue.notification-recipient/recipient-type`.

Read `:notification-routing` in `policy.edn` first. After the Vendor’s ETA Code
is known, call this collection **only for the types that rule needs**, in a
**separate** query from owner/PO/ETA joins that use a two-key entity.

| After ETA normalize (trim + upper) | Atlas `recipient-type` calls | Buyer |
|---|---|---|
| `SC` `NR` `US` `RQ` | `"VENDOR"` then `"EMT"` | from current owner/PO |
| `SH` `LS` | none | To from current owner/PO only |
| `DD` | `"WAREHOUSE"` | CC from current owner/PO |

### Vendor contacts

```clojure
{:entity
 {:pastdue.vendor-contribution/country-code "US"
  :pastdue.vendor-contribution/vendor-code 12345
  :pastdue.notification-recipient/recipient-type "VENDOR"}
 :query
 [({:pastdue.vendor-contribution/notification-recipients
   [:pastdue.notification-recipient/recipient-type
    :pastdue.notification-recipient/email
    :pastdue.notification-recipient/contact-name
    :pastdue.notification-recipient/is-recommended
    :pastdue.notification-recipient/contact-priority-score
    :pastdue.notification-recipient/contact-role-hint
    :pastdue.notification-recipient/selection-reason
    :pastdue.notification-recipient/source-system]}
   {:limit 100})]}
```

Prefer recommended / higher `contact-priority-score` in the Agent when ranking
candidates; only add `order_by` if discovery `:allowed` includes the priority
attribute for this collection.

### Country-wide EMT or Warehouse

Keep the Vendor under analysis in `:entity` (required by the resolver). SQL
returns active rows with table `vendor_code = 0` for that Country and type.
Replace only `recipient-type` with `"EMT"` or `"WAREHOUSE"`.

```clojure
{:entity
 {:pastdue.vendor-contribution/country-code "US"
  :pastdue.vendor-contribution/vendor-code 12345
  :pastdue.notification-recipient/recipient-type "EMT"}
 :query
 [({:pastdue.vendor-contribution/notification-recipients
   [:pastdue.notification-recipient/recipient-type
    :pastdue.notification-recipient/email
    :pastdue.notification-recipient/contact-name
    :pastdue.notification-recipient/is-recommended
    :pastdue.notification-recipient/contact-priority-score
    :pastdue.notification-recipient/contact-role-hint
    :pastdue.notification-recipient/selection-reason
    :pastdue.notification-recipient/source-system]}
   {:limit 100})]}
```

Do **not** put `notification-recipients` in the same `:query` as
`current-owner-risks` / `current-high-risk-lines` / ETA drivers when `:entity`
only has country + vendor. That yields `meta.unreached` for
`notification-recipients` even though the join exists. If `unreached` appears,
add the missing `recipient-type` and retry once per the metadata table below.
A successful empty list means no contacts for that type (`RECIPIENT_UNRESOLVED`
for that group), not a planning failure.

## Result handles and analysis tools (Open Atlas MCP)

This graph MCP exposes `execute_eql` and `analyze_result` (no separate
`read_result` / preview tool). Large results — and any call with
`retain_result=true` — return a `result_handle` instead of inline rows.

### How to get row values

1. Call `execute_eql` as usual. A handle with `result-complete: true` means the
   saved result is ready; it is **not** yet a Country table you can report.
2. Call `analyze_result` on that handle:
   - **Omit `sql`** → schema only (`row-count`, column names/types). **No cell
     values.** Never stop the daily workflow after only this step.
   - **Pass `sql`** → DuckDB over the in-memory table named `data`. Column names
     are the attributes’ **local** names (`pastdue.country-monitor/country-code`
     → `country_code`). This returns `rows` and is the materialization step.
3. Example for the Country monitor handle (adapt the SELECT list to the
   projected fields; `analysis_version` 2 keeps numeric types):

```text
analyze_result(
  result_handle: <handle from execute_eql>,
  analysis_version: 2,
  sql: "SELECT country_code, latest_snapshot_date, previous_snapshot_date,
               snapshot_gap_days, latest_snapshot_age_days,
               latest_past_due_count, previous_past_due_count,
               latest_open_count, previous_open_count,
               latest_past_due_ratio, previous_past_due_ratio,
               relative_ratio_change, percentage_point_change,
               zero_baseline_increase, has_comparable_snapshots
        FROM data
        ORDER BY country_code")
```

4. Prefer `SELECT … FROM data` (or aggregates) for reporting. Do not invent a
   second Source/database. Reuse the same handle for further SQL when useful
   (`analysis.materialized=true` on later calls).
5. `result-complete: true` with
   `source-completeness: unknown` / `result/collection-coverage-unknown` is the
   **normal default** for this MCP on collection queries. The engine does not
   independently certify “full source” coverage for resolver-backed lists, so it
   labels coverage unknown. That is **not** a data error, **not** an ETA
   failure code, and **does not** alone justify “部分完成 / Partial”. It does
   **not** block Country status (NORMAL / TRIGGERED) or Vendor brief lists when
   returned rows are present and `result-complete` is true. Mention it at most
   once as a generic caveat; do not treat it as the main finding or refuse to
   classify. Prefer `result-complete`, `truncated?`, handle ownership checks, and
   row identities for whether the query answer is usable. For
   `bulkhead_rejected`, use the recovery table + `:execution-plane` kernel
   concurrency degrade (one work-item retry after backoff; continue other
   pending items; budget is shared across capabilities).
6. After a successful Country handle + SQL that returns US/CA rows, **continue
   the Skill workflow immediately** (trigger check → Top-10 → ETA → …). Do
   **not** ask the user for permission to continue.
7. `retain_result=true` is optional for small results; if used, the next required
   step is still `analyze_result` **with** `sql`. Omitting `retain_result` may
   still yield a handle when the server deems the payload large — same rule.
8. Never reuse a handle across unrelated worklist items. Further SQL on the
   **same** item’s handle is fine; switching Vendor/collection requires a new
   `execute_eql`.

## Response metadata

Unwrap nested text/JSON response payloads. Outer `isError: false` or a tool marked Completed does not guarantee success. Inspect inner `error`, `problems`, `meta.unreached`, access, empty hints and truncation/spill metadata before interpreting a result.

| Signal | Action before at most one corrected retry |
|---|---|
| `unknown-attribute` | Confirm the exact deployed name and meaning via metadata/suggestions; repair fields AND check the complete input tuple before retrying. Do not choose a similarly named field with a different meaning. |
| `order-not-allowed` / `engine.request/order-not-allowed` | Drop `order_by` (use resolver default) or set it from discovery `:order`/`:sort :allowed` for this collection. Do not retry with SQL snake_case column names unless discovery lists them. |
| `unreached` | Check required inputs in the correct namespace against the template/contract. For `notification-recipients`, ensure `:entity` includes `pastdue.notification-recipient/recipient-type` (`VENDOR` / `EMT` / `WAREHOUSE`) in addition to country + vendor; do not retry the same two-key entity. Fill only values derivable from request/policy/time. Do not invent an `/all` entry or search for arbitrary relationships. |
| `irrelevant-entity-key` | First check for missing members of the input tuple. With incomplete inputs the planner may not select a resolver, making a required key appear unused. Do not remove threshold from these historical queries. With all inputs correct, inspect deployed resolver metadata and report a contract mismatch if unresolved. |
| SQL source / JSON serialization failure | Record the resolver and exact error; retry only with an evidence-backed query correction. Changing limits is not a fix for SQL or JDBC type errors. Stop dependent attribution if still unavailable. |
| `bulkhead_rejected` / `:error/category :bulkhead_rejected` | Back off; one corrected retry for that worklist item; set **shared** kernel concurrency to `:concurrency-degraded`; do not retry-storm or combine collections. Continue other pending items (any capability). |
| `engine.request/unreachable` | Wrong entry/root. Switch to a declared capability entry (e.g. `master-mappings` not mapping-entity root). Classify `UNREACHABLE` if no reachable path after one corrected attempt. |
| Access denial | Report ACCESS_DENIED and stop the denied path; never retry through a bypass. |
| Successful complete empty collection | Report no returned triggers among available comparable snapshots, with coverage limitations. This is not a validation failure. |
| Missing collection / `result {}` | Answer unknown, not “no triggers”. Distinguish unreachable from a valid empty event collection. |
| Truncated/spilled collection | Read available spill/paging within the deployed contract before claiming completeness; otherwise report partial results. |
| Analysis-only view of a handle | Expected when `analyze_result` omits `sql`. Immediately re-call with `sql` over `data` (local column names). Do not ask the user to continue and do not claim Country rows are missing. |

The retry budget is one corrected data call per logical query (Country + range + collection), not one per error type. Inspect relevant metadata and fix all detectable issues together before spending it. Continue independent Country queries; do not turn one failure into a two-Country “none”.

No returned event means there is no evidence for “有”. A no-trigger statement requires a successful complete empty collection; if scan coverage matters or an empty hint is ambiguous, query `comparisons` with the same four inputs to distinguish normal comparable dates from no comparable data. Missing comparisons may mean missing snapshots or no prior snapshot, not normal dates.

When diagnosing failures retain mode, Country, UTC anchor/range, threshold, collection/resolver, attempt (1 or 2), stage, and request_id when present. Use these details in failure reports; do not invent IDs or infer that SQL ran from a planning response.
