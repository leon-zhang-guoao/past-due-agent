# Metric definitions

## Snapshot pairs

A completed snapshot has `snapshot_date < current UTC date`.

- Daily mode: latest two available completed snapshots per Country.
- Historical mode: each target date in the inclusive requested range is paired with the nearest available completed snapshot before it. The previous date may be before range start.

Never assume the dates are consecutive. Display the actual gap.

## Country calculation

```text
target_ratio   = target_past_due_count / target_open_count
previous_ratio = previous_past_due_count / previous_open_count
relative_change = (target_ratio - previous_ratio) / previous_ratio
point_change    = target_ratio - previous_ratio
```

Use unrounded values for classification. Round only presentation.

Trigger when previous ratio > 0 and relative change >= 0.10. If previous ratio = 0 and target ratio > 0, classify `ZERO_BASELINE_INCREASE`. If both are 0, it is not a trigger. Point change is display-only.

## Daily status priority

1. `ACCESS_DENIED`
2. `DATA_ERROR`
3. `INSUFFICIENT_DATA`
4. `STALE_SNAPSHOT` when latest age > 2 UTC days
5. `ZERO_BASELINE_INCREASE`
6. `TRIGGERED`
7. `NORMAL`

Historical events are labeled by explicit target/previous dates and must not be represented as current daily status.

## Vendor contribution

```text
target_country_contribution(v) = target_vendor_past_due(v) / target_country_open
previous_country_contribution(v) = previous_vendor_past_due(v) / previous_country_open
delta_country_contribution(v) = target_country_contribution(v) - previous_country_contribution(v)
positive_share(v) = positive_delta(v) / sum(all positive Vendor deltas)
```

All Vendor deltas reconcile, within floating-point tolerance, to the Country point change. Positive share is not share of net change when negative offsets exist.

## ETA contribution

Apply the same Country denominator at Country + Vendor + ETA Code and independently at Country + Vendor + ETA Source. Blank/null values normalize to `UNKNOWN`.

## Full ETA changes and reconciliation

Default selection is fixed positive Vendor Top-10, ties by Vendor Code ascending. Coverage 80% is descriptive and never an early stop. Each selected Vendor must receive both ETA analyses or explicit failure states.

Both default ETA collections use the explicit Country trigger pair. Daily `latest-snapshot-date` maps to historical `target-snapshot-date`; Country, Vendor and previous date remain unchanged. Validate the returned pair against Country and Vendor facts before combining. If daily Vendor dates move during a run, query historical Vendor contributors with the original Country pair and rebuild the whole Country Top-10, rather than mixing rankings from different pairs. This is a date-pinning correction subject to the existing single retry limit; if unresolved, mark the Country attribution unavailable.

For bucket b:

```text
count_change(b) = target_count(b) - previous_count(b)
count_relative_change(b) = count_change(b) / previous_count(b), only if previous_count > 0
increase_total = sum(max(count_change(b), 0))
decrease_total = sum(min(count_change(b), 0))  # signed, nonpositive
net_change = increase_total + decrease_total
```

Zero baseline relative change is null: show zero-baseline increase when target>0, no change when both zero. A target zero with positive previous count yields -100%. Normalize null/blank ETA to UNKNOWN before grouping. Retain the two-period union, including rows that only existed in one snapshot and zero/negative changes. Absence may become zero only within a validated pair and complete query.

After all pages are retrieved and reconciled, sort abs(count_change) DESC, target count DESC, ETA value ASC. Show five values and Other from remaining rows. Sum both periods and contributions for Other, then recompute its relative change; never average percentages. Sum all increases/decreases even when the five displayed rows are all increases. Do not derive a complete total from the first page or legacy positive drivers.

Each dimension separately must sum to Vendor counts (exact integers), previous/target Country contributions and contribution delta (abs_tol=1e-9, rel_tol=1e-9, unrounded ratio units). Code and Source totals overlap and must never be added. Country denominator effects can make a declining count have a positive contribution delta; describe both facts. Bucket changes are not proof that specific PO lines migrated between codes. Current PO facts cannot establish a historical migration.

## Vendor classification

Apply precedence:

1. `NEW_EXPOSURE`: previous open = 0, target open > 0, target past due > 0.
2. `DENOMINATOR_EFFECT`: target past due <= previous past due but contribution delta > 0.
3. `DETERIORATING`: target Vendor ratio > previous and target past due >= previous.
4. `VOLUME_GROWTH`: target past due and open counts increase without a materially higher Vendor ratio.
5. `MIXED`: no earlier label cleanly explains the facts.

These are diagnostic metric labels, not personal blame.

## Current risk

Current PO candidate:

```text
risk_level = "HIGH_RISK" OR is_past_due = true
```

Buyer, Primary, Manager, and PO-line rows have no historical snapshot and are current context only.
