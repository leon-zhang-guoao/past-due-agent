# Atlas data contract

**Live authority:** Open Atlas MCP `list_entities` / `list_attributes` for the
connected graph. This file is a checklist of expected PastDue entities; if MCP
differs, trust MCP and report a mismatch.

## Daily entities

- `pastdue.country-monitor`, identity `country-code`; collections `all`, `positive-vendor-contributors`, `vendor-changes`, `vendor-master-mapping-rollups`.
- `pastdue.vendor-contribution`, identity `country-code + vendor-code`; collections `eta-code-drivers`, `eta-source-drivers`, `current-owner-risks`, `current-high-risk-lines`, `master-mappings`, `notification-recipients`.
- `pastdue.vendor-master-mapping`, identity `country-code + vendor-code + department-type`; current DNA department / primary / manager from `vendor_master_mapping_view`.
- `pastdue.vendor-master-mapping-query`, identity `country-code + department-type-filter + master-primary-filter + master-manager-filter` (empty string = no filter); collection `matching-mappings`.
- `pastdue.vendor-master-mapping-rollup`, identity `country-code + department-type + master-primary + master-manager`; reached from `pastdue.country-monitor/vendor-master-mapping-rollups`.
- `pastdue.vendor-eta-code`, identity `country-code + vendor-code + eta-code`.
- `pastdue.vendor-eta-source`, identity `country-code + vendor-code + eta-source`.
- `pastdue.owner-current-risk`, identity `country-code + vendor-code + owner-role + owner-display`.
- `pastdue.current-high-risk-line`, identity `order-type + po-number + po-line-number`.
- `pastdue.notification-recipient`, identity `country-code + vendor-code + recipient-type + email`; reached from `pastdue.vendor-contribution` as `notification-recipients`. The resolver **requires** `recipient-type` in `:entity` together with vendor-contribution country and vendor codes (see playbook). Candidate rows expose content-derived role, priority score, recommendation flag, selection reason and redacted evidence.

## Historical entities

- `pastdue.country-history-query`, identity `country-code + range-start-date + range-end-date + relative-change-threshold`; collections `comparisons`, `trigger-events`.
- `pastdue.country-trigger-event`, identity `country-code + target-snapshot-date + previous-snapshot-date`; collections `positive-vendor-contributors`, `vendor-changes` (UAT: no Country-pair batch ETA joins).
- `pastdue.historical-vendor-contribution`, identity `country-code + vendor-code + target-snapshot-date + previous-snapshot-date`; collections `eta-code-drivers`, `eta-source-drivers` (legacy positive-only), `eta-code-changes`, `eta-source-changes` (**default** all-change path for daily and historical Top-10 drilldowns).
- `pastdue.historical-vendor-eta-code`, identity `country-code + vendor-code + target-snapshot-date + previous-snapshot-date + eta-code`.
- `pastdue.historical-vendor-eta-source`, identity `country-code + vendor-code + target-snapshot-date + previous-snapshot-date + eta-source`.

Historical Vendor/ETA resolvers reject a supplied pair unless both snapshots exist, target is completed, previous < target, and previous is exactly the nearest available snapshot before target.

Both historical Country collections require the full four-part query identity in `:entity`. `comparisons` consumes the threshold to classify `trigger-type`, while `trigger-events` also filters by it. These collections are not roots and this bundle declares no `country-history-query/all`. See `atlas-query-playbook.md` before constructing historical calls.

## Crossing from historical attribution to current action context

Do not invent historical Owner/PO entities. For each selected historical Vendor, construct the existing current identity:

```clojure
{:pastdue.vendor-contribution/country-code "US"
 :pastdue.vendor-contribution/vendor-code 12345}
```

Then query `current-owner-risks` and `current-high-risk-lines`. The target/previous historical dates do not carry into those current collections.

## Physical sources

- `past_due.vendor_past_due_daily`: historical daily aggregate by snapshot, Country, Vendor, ETA Code, ETA Source.
- `past_due.past_due_detail_view`: current PO-line context (Buyer via `buyer_email`, risk, quantities). **Do not** use its `department_type` / `master_primary` / `master_manager` as org mapping truth.
- `past_due.vendor_master_mapping_view`: current DNA organization mapping (`department_type`, `master_primary`, `master_manager`) by `country_code` + `vendor_no`. Distinguish countries with `country_code`.
- `past_due.vendor_eta_notification_contact`: governed notification contacts (display only).

Agent runtime never queries these tables directly; only Atlas MCP resolvers do.

## Boundaries

- Use Country + Vendor Code; Vendor Code is not globally unique.
- Atlas SQL supports every actual Country; the Agent monitoring allowlist is US/CA.
- Do not use old dashboard Top-5 views for attribution.
- Owner/person fields (Buyer, DNA Primary/Manager, contacts) are PII and may be protected by deployment roles/RLS.
- Vendor master mapping supports enrichment, filtered Vendor slices, Owner PRIMARY/MANAGER, and Country rollups — not only a single report scene.
- Notification contact email/name fields are PII. They are read through Atlas only and are display-only; no send operation is part of this bundle.
- Credentials come only from environment variables / MCP auth — not from Skill text.

## Explicit-pair ETA all-change contract

The all-change collections live on `pastdue.historical-vendor-contribution` and accept Country, Vendor Code, target date and previous date. They are used by daily AND historical drilldowns. In daily mode copy `latest-snapshot-date` to target; never recompute previous=target−1. Current Owner/PO still use Country+Vendor only.

Each change row returns full identity, normalized ETA value, two counts, count
delta, and two Country contributions plus contribution delta. Relative count
change is **not** returned by Atlas — compute in the Agent:
`null` if previous count is 0, else `(target − previous) / previous`. No
positive share/cumulative share/contribution rank on the all-change resolver.
Discover the collections before use; if absent, report deployment mismatch
instead of silently substituting positive-only drivers.
