---
name: pastdue-analysis
description: Flexible PastDue Q&A via Open Atlas MCP with machine-enforced Kernel Runtime (intent→Fact Plan→gated single-collection EQL). Compose intents into declared capabilities; daily US/CA monitor is a preset. Org mapping via vendor-master-mapping (not detail master_*). R1 on-demand org/Owner/PO/notify. Country isolation; historical vs current evidence.
---

# PastDue Analysis

Use Open Atlas MCP as the only factual data interface. Read
`references/policy.edn` (v1.7+) before executing. **Enforcement** is
`runtime/pastdue_kernel` (Fact Plan Builder, Preflight Gate, Kernel Session) —
this Skill is the operator dictionary, not a license to improvise roots.

## Kernel Runtime (required for factual calls)

When host Kernel tools are available, use them. Otherwise obey the same
contracts while calling MCP:

1. Resolve **Intent IR** (`:intent-catalog` + `:disambiguation`).
2. `build_fact_plan` → ordered work items (capability ids only).
3. Kernel: template EQL, worklist dedupe, concurrency ≤2, handle ownership,
   ≤1 retry; Gate rejects multi-collection / forbidden roots / contribution
   scalars / duplicate terminal keys (`GATE_REJECTED`).
4. Compose only from typed `WorkResult`s.

Offline check: `python scripts/run_kernel_tests.py` and
`python scripts/run_golden_eval.py`.

## Atlas MCP tool loop

You do **not** have Atlas chart files. Discover through MCP; **execute** only
Kernel-approved single-collection shapes:

| Step | Tool | Purpose |
|---|---|---|
| 1 | `list_entities` | Entities + identity keys |
| 2 | `list_attributes` / `search_attributes` | Confirm declared entries |
| 3 | `execute_eql` | One collection per call — from capability template |
| 4 | `analyze_result` + `sql` | Only the handle owned by that work item |

## References

- `references/policy.edn`: thresholds, `:execution-plane`, `:intent-catalog`, `:disambiguation`.
- `runtime/pastdue_kernel/`: machine Kernel (source of enforcement).
- `references/metric-definitions.md`: formulas and classifications.
- `references/atlas-query-playbook.md`: capability dictionary + recovery (not a parallel concurrency policy).
- `references/report-format.md`: composition assembly.
- `references/table-display-contract.md` / `.edn`: table modules.
- `references/data-contract.md`: checklist — **verify against MCP**.

## Output language

Match the **user's request language** for the whole report (headings, tables,
status labels, recommendations, limitations). English request → English
report. Chinese request → Chinese report. Do not default to Chinese because
reference examples or section names in this Skill use Chinese. Scheduled
prompts count as the request language. Keep Country/Vendor codes, ETA codes,
dates, and numeric values unchanged.

## Interactive path (primary for user Q&A)

Do **not** force every ask into the daily Top-10 script. Flow:

1. Classify **intents** (table below / `policy.edn` `:intent-catalog` +
   `:disambiguation` — e.g. 占比→`eta-*-changes`, not drivers-as-share).
2. Build a **Fact Plan** via Kernel Builder (ordered capability ids + scope).
3. Run through **Kernel Session** (gate + worklist). Do not re-implement
   concurrency in prose.
4. **Compose** from typed results; mark historical vs current; typed failures.

| Intent | Examples | Capabilities (confirm via MCP) | Tier |
|---|---|---|---|
| `:country-health` | 国家怎么样 / latest monitor | `:country-monitor-all` | hist pair |
| `:who-triggered` | 谁触发了 | monitor + classify | hist |
| `:vendor-drivers` | Top vendors / 谁贡献 | `:positive-vendor-contributors` | hist |
| `:vendor-snapshot-metrics` | 这 vendor past due 多少 | contributors or `vendor-changes`, **filter** `vendor_code` — never contribution-root scalars | hist |
| `:eta-decomposition` | ETA code/source 构成 | `:eta-code-changes` then `:eta-source-changes` | hist |
| `:org-mapping` / `:eta-specialist` | 负责人 / ETA specialist | `:master-mappings` (ETAD → primary) | **current** |
| `:org-filter` | 按部门筛 | `:matching-mappings` | current |
| `:org-concentration` | 集中度 | `:mapping-rollups` | current |
| `:owner-risk` | owner 风险 | `:owner-current-risks` | current |
| `:po-line-detail` | detail / 每一行 / PO 明细 | `:current-high-risk-lines` | current |
| `:notify-who` | 通知谁 | `:notification-recipients` | current |
| `:historical-range` | 过去一周 | history `trigger-events` | hist |

**“Detail” default:** for a named Vendor, include `:po-line-detail` (and
`:vendor-snapshot-metrics` if counts/ratios not already in session). Label PO
rows **current context**.

**Example Fact Plan — “CA vendor 40979 past due detail”:**  
(1) `:positive-vendor-contributors` for CA → analyze `WHERE vendor_code=40979`  
(2) `:master-mappings` alone  
(3) `:current-high-risk-lines` alone  
(4) optional `:eta-code-changes` if ETA split requested  
Never one EQL bundling scalars + mappings + PO lines.

If no intent matches and discovery finds no reachable entry → **capability gap**
(explain missing path). Do not guess roots.

## Choose the mode

### Daily monitor

**Preset** Fact Plan for the external daily scheduler and bare “latest monitor”
asks. Not the only interactive shape.

1. Query all Country monitor facts and retain US/CA.
2. Use each Country's latest two available completed UTC snapshots.
3. Always output the Country table.
4. Deep-dive only triggered/zero-baseline Countries. **Do not stop after the
   Top-10 Vendor list without ETA queries.** With the confirmed Country
   target/previous dates (daily: latest→target, keep previous), follow
   **Universal Execution Kernel** in `atlas-query-playbook.md` and
   `policy.edn` `:execution-plane` (capabilities `:eta-code-changes` then
   `:eta-source-changes`):
   (a) build a worklist: each selected Vendor × Code then Source as
   **separate** `execute_eql` calls (never combined); enqueue Tier A ranks
   1…`:tier-a-ranks` before Tier B; confirm joins via `list_attributes`;
   (b) run on the **shared** kernel concurrency budget (degrade on
   `bulkhead_rejected`, recover after consecutive OK); bind each
   `analyze_result` only to that item’s handle;
   (c) fill `vendor_summary` **brief list** columns
   `eta_code_changes_brief` / `eta_source_changes_brief` (up to Top-5:
   abs count Δ DESC, target count DESC, ETA value ASC; format
   `SH +290；NR +122`); Source values must be `eta-source`, not codes;
   on `failed_final` use `—` + failure code (`BULKHEAD` / `HANDLE_*` /
   `SOURCE_ERROR`);
   (d) **default display** = Country metrics + `vendor_summary` + brief
   coverage prose — do **not** expand full ETA / metrics / Owner / PO /
   notification / org-mapping tables unless the user asks. Under pressure,
   drain Tier A then Tier B briefs before recommendations.
5. Keep US and CA independent, then add a Country-level summary. ETA items
   across Countries share one concurrency budget.
6. **One response / full obligation:** finish Code then Source for **all**
   selected Vendors on **all** triggered Countries before recommendations
   when Atlas allows (`:tiered-priority-full-obligation`). Forbidden exits:
   stopping after a few Vendors; voluntary `未查询` / not queried for
   capacity; “下轮继续 / continue next turn / I’ll finish ETA later”.
7. **Org mapping R1:** do **not** auto-query `master-mappings` for Top-10 in
   the default daily summary. Query org only for department / Primary /
   Manager / concentration / filter asks, or an explicit enrich request (see
   Organization analysis).

Stopping after Top-10 without querying ETA (or inventing brief lists) is a
workflow failure when Atlas is reachable. Dumping ten full Code+Source tables
in the default report is also wrong — use the summary brief columns. Partial
is allowed only for worklist `failed_final` / `HOST_PARTIAL` (not for
`collection-coverage-unknown` alone) — then use fail placeholders / name
unfinished Country+Vendor+collection items. Do **not** plan a second turn to
finish ETA. Full ETA tables, metrics, owners, notification, PO lines, and org
mapping are on-demand (R1).

### Historical review

Use only for explicit date, date-range, “past period”, or historical intent.

Before calling Atlas, read `references/atlas-query-playbook.md` (date rules,
historical template, recovery) and confirm identity keys via MCP. Both
historical collections require Country + start date + end date + threshold in
`:entity`. Never start with an empty entity or threshold alone. Use
`target-past-due-ratio` and `trigger-type` from the historical entity.

1. Resolve current UTC date D from trusted runtime time; “过去一周/最近7天” is D−7 through D−1 inclusive. Show the range and proceed without confirmation. Never reuse static example dates. Maximum 366 calendar dates; see playbook for calendar weeks and custom ranges.
2. Query requested Countries independently with `country-history-query/trigger-events` (default US/CA). Read threshold from policy; a clearly requested historical what-if override is local to the request.
3. The range applies only to target dates. The comparison date is the nearest available prior snapshot and may be before range start.
4. List all trigger events.
5. Default deep-dive: latest trigger event per Country. Honor explicit event-list-only requests. Explicit “all” request: max 5 events per Country.
6. For selected events query fixed positive Top-10 historical Vendor
   contributors, then per-Vendor ETA via the Execution Kernel (capabilities
   `:eta-code-changes` / `:eta-source-changes`). Latest event per Country:
   full Top-N. Older events beyond latest: Tier A first unless the user asks
   full.
7. If current action context is requested or useful, query existing current
   Owner resolvers by Country + Vendor Code and label results as current.
   PRIMARY/MANAGER come from `master-mappings` /
   `vendor_master_mapping_view` (not detail-view master_* columns). BUYER
   remains detail `buyer_email`. Query high-risk PO lines only on explicit ask.
8. Organization analysis — see below (R1 on-demand).

Never route a scheduled daily run into historical review.

### Organization analysis (R1 — multi-scenario, not Owner-only)

Physical truth: `past_due.vendor_master_mapping_view` via Atlas
`pastdue.vendor-master-mapping*`. Forbidden: detail-view `department_type` /
`master_primary` / `master_manager`. Label all results **current org context**.

| Ask | Use |
|---|---|
| Enrich one/several Vendors | `pastdue.vendor-contribution/master-mappings` |
| Filter Vendors by dept / primary / manager | `matching-mappings` (empty-string filter = no constraint) |
| Concentration in a Country | `vendor-master-mapping-rollups` |
| Owner risk table | `current-owner-risks` (BUYER=detail; PRIMARY/MANAGER=mapping) |

May cross org conclusions with Top-10 contribution shares; never substitute
org mapping for ETA attribution. Playbook has EQL shapes; confirm names via
MCP. Always use kernel capability `:master-mappings` (forbidden: mapping
entity as EQL root). Fan-out shares the global concurrency budget with ETA.

## Flexible questions (dictionary, not a closed scene list)

Templates and the intent table fix **reachable entries and inputs**, not the
closed set of allowed English/Chinese questions. Compose multiple intents in
one answer. Adjust dates, Countries, thresholds, and projections. New
attributes: discover schema first, then Kernel-valid EQL. A field absent from
a template is not automatically unsupported. Preserve Country isolation,
access controls, and historical/current attribution limits.

**Extending:** new question family → add intent synonym + capability in
`policy.edn` (and Atlas resolver if no path exists). Do not invent a parallel
calling style outside the Kernel.

For `order_by`, follow discovery `:order` / `:sort :allowed` (or omit and use the
resolver default). Do not hardcode SQL column aliases from templates.

Open Atlas MCP: `execute_eql` may return only a `result_handle`. Calling
`analyze_result` **without** `sql` yields schema/`row-count` only. To read facts,
call `analyze_result` **with** DuckDB `sql` over table `data` (local column
names). Then continue the daily workflow — do not ask the user to approve
continuation. See `references/atlas-query-playbook.md` (Sorting; Result handles).

## Contribution selection

Read `references/report-format.md` and `references/metric-definitions.md` before triggered drilldown. Vendor: positive Country contribution descending, Vendor Code ascending; take 10 (or all if fewer). Do not stop when coverage reaches 80%. Coverage refers to all positive Vendor contributions, not net change.

For triggered drilldowns fetch per-Vendor ETA Code then ETA Source for each
selected Vendor (including decreases and zeros). Default report puts up to
Top-5 buckets per dimension into `vendor_summary` brief cells
(`CODE +N；…` / `Source +N；…`). When the user asks for full ETA tables, use
the same sort; show five values + Other; report increase/decrease/net totals;
reconcile to Vendor facts. Do not request `past-due-count-relative-change`
from Atlas — compute from counts (`null` when previous is 0). Positive-only
drivers remain for explicit positive-attribution asks only.

Daily latest-snapshot-date maps to historical target-snapshot-date; keep Country, Vendor and previous date unchanged. All returned Vendor/ETA dates must match the triggering Country pair. Call this a previous-day change only when the gap is one day.

Use all-change collections only for reconciliation, improvements, or negative-offset questions.

## PO-line allocation

Maximum 5 current lines per Vendor and 20 per Country. Give one candidate to each selected Vendor first, then fill in Vendor contribution order.

## Report completion

**Template-first:** For any analytic report (including no-trigger daily), read
`references/report-format.md` (gate) and resolve composition + modules from
`references/table-display-contract.edn` before writing tables. Contracted
modules define tables; missing modules → prose + disclose no template.
Prose sections stay flexible.

Full daily/historical runs use compositions (`daily_full` /
`historical_full` / `historical_events_only`). Default triggered display is
`vendor_summary` (with ETA brief lists) only; on-demand/standalone asks
render only the matching module(s) with the **same** templates. Every selected
Vendor must have Code+Source **queried** (or explicit failure) so brief cells
are filled — not a full ETA dump. Never replace remaining Vendors with
“others similar”. A missing changes collection is a deployment mismatch.

Before the final recommendations block (same response, no deferral): every
selected Vendor on every triggered Country must already have ETA Code and ETA
Source queried (or an explicit per-Vendor Atlas-failure status) for brief
cells. Do not end a triggered daily run with “ETA not queried”, “部分未查”,
or “下轮继续” while those Vendors remain unfinished and Atlas did not fail.

## Evidence and error boundaries

Country/Vendor/ETA daily snapshots may support two-snapshot historical attribution. Owner and PO data are current context only. Inspect Atlas error, access, empty, truncation, and spill metadata. Retry a corrected query at most once; never bypass denied access or invent missing facts.

Inspect nested payload errors even when outer `isError` is false. For unknown fields or unreachable collections, repair all detectable field/input issues together before that one retry. A missing result is not an empty event collection; without successful event data, say the answer is unknown. Continue independent Countries when one fails. Follow the playbook **Universal Execution Kernel** for all Atlas fan-out (including `bulkhead_rejected`, handle ownership, and forbidden roots).

## Alert recipient display (current scope)

If a Country alert triggers (or a Vendor section needs recommended To/CC),
read `:notification-routing` in `references/policy.edn`, then follow this
order. Do not call Python, read the CSV, generate or send email, schedule
follow-ups, track replies, or escalate. The local `notification/` folder is
documentation only.

### Required call order (do not skip)

1. **Finish ETA Code facts first** for that Vendor (changes or drivers). Pick
   the ETA Code that drives the alert/routing for this Vendor (trim +
   uppercase). Do not query contacts before the ETA Code is known.
2. **Map ETA Code → rule** from `policy.edn` `:notification-routing` `:rules`:
   - `SC` / `NR` / `US` / `RQ` → To `:vendor`, CC `:emt` + `:buyer`
   - `SH` / `LS` → To `:buyer` only (no Atlas contact collection call)
   - `DD` → To `:warehouse`, CC `:buyer`
3. **Query only the Atlas contact types the rule needs.** Collection:
   `pastdue.vendor-contribution/notification-recipients` (confirm via MCP).
   Every such call **must** put all three keys in `:entity`:
   - `pastdue.vendor-contribution/country-code`
   - `pastdue.vendor-contribution/vendor-code` (the Vendor under analysis;
     for EMT/WAREHOUSE the resolver still requires this key; SQL selects
     country-wide rows with table `vendor_code = 0`)
   - `pastdue.notification-recipient/recipient-type` — `"VENDOR"`, `"EMT"`,
     or `"WAREHOUSE"` exactly as required by the rule
4. **Buyer** comes only from current Atlas Owner/PO facts, never from the
   notification-recipients collection.
5. Use the playbook templates in `references/atlas-query-playbook.md` under
   **Notification recipients**. Never attach `notification-recipients` to an
   `:entity` that only has country + vendor (same shape as owner/PO joins):
   Atlas will mark the collection `unreached`.

Missing required To/CC groups → status `RECIPIENT_UNRESOLVED` and list the
missing groups. Empty successful results are unresolved contacts, not
unreachable.

For irregular contact text, use Atlas candidate metadata rather than guessing:
prefer `is-recommended = true`, then higher `contact-priority-score`, while
using `contact-role-hint`, `selection-reason` and redacted `evidence-text` to
explain the choice. Do not select internal/automated addresses as Vendor
recipients unless the returned metadata explicitly marks them recommended. If
multiple candidates remain ambiguous, display them as unresolved candidates
instead of silently choosing one.

## Optional arithmetic helper

If Python is available, `scripts/drilldown_math.py` can select fixed Top-10 or validate/summarize one complete ETA dimension from Atlas-returned JSON facts; it never queries a database. Use unqualified hyphenated field names, full Country/Vendor/date identity, and unrounded numeric values. Supply `complete: true` only after Atlas paging/spill checks. Its input contract is in the script docstring. `verify_sections` can check summary/detail order when importing the module. The helper is optional: without Python perform the same calculations and checks from the metric/report references; no external runtime service is required.
