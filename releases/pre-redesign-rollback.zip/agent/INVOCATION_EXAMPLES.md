# Invocation examples

## Daily monitor — fixed Top-10 drilldown

- `运行今天的 PastDue daily monitor。`
- `输出 US 和 CA 最新完整快照的日报。`
- `Run the scheduled daily PastDue report.`

Expected mode: `DAILY_MONITOR`; discover joins via Atlas MCP; Country/Vendor
Top-10 then per-Vendor `eta-code-changes` / `eta-source-changes`, then current
Owner/PO context.

## Historical trigger discovery

- `过去 30 天 US 和 CA 哪些快照的 Past Due Ratio 相对增长达到 10%？`
- `检查 2026-08-01 到 2026-08-18，列出每个 Country 的触发日。`
- `2026-08-17 这个目标快照是否触发？`

Expected mode: `HISTORICAL_REVIEW`; resolve/display exact UTC range and list every trigger event.

## Historical attribution

- `找出过去 60 天的触发日，并下钻每个 Country 最新的触发日。`
- `把 2026-08-17 对比最近前一快照的 US 上升原因下钻到 Vendor 和 ETA。`
- `过去 90 天所有触发事件都下钻。`

Default: latest trigger per Country. Explicit “all”: newest maximum 5 events per Country.

## Historical attribution plus current action context

- `对历史触发 Vendor 再给出当前 Buyer、Primary、Manager 和高风险 PO 行。`

The report must label Owner and PO rows as current context, not historical causation.

## Reconciliation/offset questions

- `US 在 2026-08-17 的全部 Vendor 正负贡献能否和 Country 变化对上？`
- `哪些 Vendor 抵消了这次上升？`

Use the historical `vendor-changes` entry, not only positive contributors.

## Complete Vendor change report

- `触发时逐家分析每个 Country 的正向贡献 Top10 Vendor，展示 ETA Code 和 Source 较上一快照的变化。`
- `只列过去一周触发日，不下钻。`
- `对 US 最新触发事件完整下钻；某个 Vendor 查询失败也请保留它的位置。`

Default drilldown: exactly the selected positive Top-10 (or fewer if fewer exist); each dimension shows absolute-count-change Top-5 + Other. Explicit positive-only ETA attribution may use legacy drivers and must be labeled accordingly.
