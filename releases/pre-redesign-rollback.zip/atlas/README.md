# Open Atlas deployment

## Load together

```text
sources.edn
charts/pastdue.edn
```

`charts/pastdue.edn` is the **authoritative** Atlas Semantic Contract for this
bundle. Deploy that file (plus `sources.edn`) into Atlas. Split
`*.attr.edn` files are non-authoritative reference shards only.

Org mapping (R1): `vendor_master_mapping_view` via master-mappings / filter /
rollups — on-demand in the Agent; not auto-enriched on default daily Top-10.

Current-state edges (not daily preset): `current-vendor-rank-query/matching-ranks`,
`current-alert-type-query/matching-counts`, `current-detail-query/matching-lines`
— aggregate/slice `past_due_detail_view` with org filters from mapping view only.

Country/Vendor daily SQL remains available. `pastdue.edn` includes explicit-pair
all-change ETA collections (`eta-*-changes`) and notification recipients; legacy
positive-only drivers remain compatible for explicit asks.

## Environment

```bash
PASTDUE_CLICKHOUSE_JDBC_URL='jdbc:clickhouse://HOST:8123/past_due?compress=0'
PASTDUE_CLICKHOUSE_USERNAME='...'
PASTDUE_CLICKHOUSE_PASSWORD='...'
```

Ensure your Atlas configuration layer expands environment placeholders or inject secrets via your approved secret manager. Do not commit credentials.

Physical objects:

- `past_due.vendor_past_due_daily`
- `past_due.past_due_detail_view` (PO-line / Buyer; not DNA Primary/Manager mapping)
- `past_due.vendor_master_mapping_view` (department / primary / manager by country + vendor)
- `past_due.vendor_eta_notification_contact`

Important physical-column naming: `past_due.vendor_past_due_daily` stores ETA
Source in the column `source`. `eta-source` is only the Agent-facing attribute
name; SQL must use `d.source` (not `d.eta_source`) and map the result to the
ETA Source attribute.

## Resolver intent

- Atlas SQL supports all actual Countries; Agent policy monitors US/CA.
- Historical ranges apply only to target dates and are guarded to 366 calendar dates.
- Historical target/previous identities are accepted only when previous is the nearest available snapshot before target.
- Vendor and ETA contribution use respective Country open denominators and preserve two-period union behavior.
- Owner and PO resolvers remain current-state only and are reused rather than duplicated.
- No Vendor-Code-only equivalence is declared.
- Triggered drilldowns call per-Vendor ETA changes for each selected Top-10 Vendor.

## ClickHouse analyzer guard

The deployed ClickHouse analyzer rejects both joined-period forms below:

```sql
-- UNKNOWN_IDENTIFIER
snapshot_date IN (p.latest_snapshot_date, p.previous_snapshot_date)

-- INVALID_JOIN_ON_EXPRESSION
(
  d.snapshot_date = p.latest_snapshot_date
  OR d.snapshot_date = p.previous_snapshot_date
)
```

The target/previous historical equivalents are rejected for the same reason. Every Vendor/ETA period resolver must instead create `period_rows` with `UNION ALL`, emit one row for each of the two snapshot dates, and join with only equality predicates:

```sql
INNER JOIN period_rows p
  ON d.country_code = p.country_code
 AND d.snapshot_date = p.snapshot_date
```

The bundle validator rejects both unsafe SQL forms.

## Validate

1. Run `python3 ../scripts/validate_bundle.py` from this directory, or `python3 pastdue-agent/scripts/validate_bundle.py` from the workspace root.
2. Run the deployed Atlas config-check against the loaded `pastdue.edn` graph.
3. Confirm discovery shows the expected entities/resolvers (including per-Vendor `eta-*-changes` and notification-recipients). Offline `validate_bundle.py` counts should match the current bundle script output.
4. Execute `../ACCEPTANCE_TESTS.md` with representative/live data.
5. Reconcile all Vendor deltas with Country point change for both daily and historical pairs.

## Security

Person fields are `:sensitivity :pii`. Add approved Atlas roles/RLS for production. Rotate any credential previously exposed in reference-only files.

## All-change ETA interfaces

Per-Vendor `eta-code-changes` / `eta-source-changes` return signed/zero changes
under the historical Vendor four-part identity. Relative count change is
computed by the Agent from target/previous counts (not returned by Atlas;
avoids JDBC `Nullable(Float64)` mapping failures). Fetch all pages with a
stable discovery-allowed sort before display selection; pagination is not
Top-5 selection.

Deploy the updated `pastdue.edn` before the updated Skill/system prompt. Current
physical tables are unchanged. Verify older drivers still answer positive-only
questions and that daily calls preserve the triggering dates, not newly
selected latest dates.

## Notification recipient display

Deploy `notification-contact-table.sql` through approved ETL before using
notification resolvers in `pastdue.edn`. The normalized table contains only
active recipient data needed for display: Country, Vendor Code, recipient type,
email, optional contact name, source system and UTC update time. It must not
contain website credentials, usernames, passwords or portal URLs.

`country_code` is required for Country-specific lookups. Existing rows must be
backfilled with their real Country through the approved ETL; do not default
them to `US` or `CA`.
