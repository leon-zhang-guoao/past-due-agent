# Retained-result reading — 3.6.1

## 1. Call boundary

This is a call procedure, NOT installed middleware. Prompt/Skill/Atlas EDN cannot
strip fields from a request after a host has constructed or sent it.

For a new source request use the actual discovered `execute_eql` schema:

```json
{"query":"<EQL with {:entity ... :query ...}>","retain_result":true}
```

For SQL reads of that request's retained result, construct only these keys:

```json
{"result_handle":"<handle from that execute response>","sql":"<SQL for that result>","analysis_version":2}
```

The result selector is exactly one of `query`, `result_handle`, `result_handles`.
Unused selectors are absent, not empty strings, empty arrays or null. Do not send
all three and assume empty values will be ignored. Do not send optional defaults
unnecessarily. A populated alternative selector must never be silently dropped to
make an ambiguous request pass. `false`/0 are not missing values.

If columns are not yet known, an optional schema discovery call is valid when the
live tool supports it: `{"result_handle":"<actual handle>","analysis_version":2}`.
It has succeeded in supplied runs. It retrieves schema/counts, not business rows.
Known verified column mappings may be reused in the same environment; discovery
is neither mandatory on every read nor the established cause of selector failure.

For `give exactly one ...`: inspect the actual submitted object. At most ONE
changed, evidence-based correction is allowed for the logical request. Remove
unused selectors if the caller can omit them; preserve the real handle. An
identical resend, version switch or source-query rerun is not a correction.
If the host still submits conflicting fields or cannot represent the valid shape,
stop dependent reads and report TOOL_ARGUMENT_ERROR with component cause
UNCONFIRMED. Do not claim the Skill executed a cleanup hook or fixed the host.

Keep actual execute/read call IDs when exposed, connection, input, handle and
capture/expiry metadata. Read handles only from their originating response, never
from an earlier run or a plausible remembered ID. A read response naming another
handle is ASSOCIATION_ERROR for that result. Missing provenance is UNVERIFIED;
quarantine dependent facts, not independent verified Countries/dimensions. If a
known current response appears expired, disclose the anomaly; only confirmed
expiry justifies a fresh execute, not guessing a replacement handle.

## 2. Small monitor and historical results

For explore-v3 pages read [explore-v3.md](explore-v3.md): SELECTION and FACT have
different scopes, counts and grains; typed placeholders are not observations.
For explore-v2 source pages, use the same actual-handle argument shape above.
Read [explore-v2.md](explore-v2.md) for repeated CONTROL, coverage records,
page-record-count, whole-result ordinals and fingerprint validation. Each source
page has its own actual handle; a cursor is not a handle. The compact report's
record/total rules below do not apply to VENDOR_COVERAGE placeholders.

For the known small monitor result:

```sql
SELECT * FROM data ORDER BY country_code
```

Read actual rows before fixing dates/triggers, then apply the requested Country
allowlist. Inspect row AND cell truncation; SELECT * does not guarantee coverage.
History results use their discovered explicit columns and supported pagination,
not a blanket small-table assumption. Do not add report-only fields to monitor.

## 3. Paged results: report-v2 and current-v2

This is the main read path for the new paged interfaces. Legacy single-handle
report projections are in section 4; they are alternatives, not extra required
reads after a complete paged read. For explore, retain its SELECTION/FACT and
coverage semantics from the matching explore reference; apply the same progress
and association checks here, with that interface's fields/control type.

### Execute, read, bind, continue — finish one Country

1. Use the complete EQL projection from report-v2-query.eql or current-v2-query.eql.
   Start source page-after-ordinal=0, report page-size=50 / CURRENT=100. Discovery
   fills a specific unresolved schema/input gap once per environment; reuse the
   shipped compatible mapping and actual successful reads. Read a focused entity
   or exact attribute when needed, rather than repeatedly listing all entities.
2. Retain the execute's actual handle. Read it once with the complete explicit
   SQL in [report-page-read.sql](report-page-read.sql) or
   [current-page-read.sql](current-page-read.sql). These read `data` behind the
   handle; they are not source SQL. Return all record types. A full page of ≤200
   rows fits this inspected reader's row cap; actual row/cell flags still decide
   completeness. If any example column is unknown, inspect the actual schema once
   and preserve all required fields; a narrower projection creates a named gap.
3. Validate the response handle equals the requested handle; validate environment,
   Country/scope, pair or CURRENT filters, returned page-after-ordinal and page-size
   against the originating request. Repeated controls must agree on expected
   count, scope and fingerprint. An unexplained reuse of a capture or a mismatched
   cursor requires association review before accepting that page. Matching numeric
   totals alone cannot repair provenance. If raw tool-call correlation is available,
   inspect that existing record; otherwise mark the affected page UNVERIFIED and
   stop its dependent work, preserving independent verified scopes. Source replays
   and guessed replacement handles do not establish the missing association.
4. Bind returned rows and their available fields before another read. A complete
   full projection covers metrics, summaries/checks or CURRENT facts and coverage
   on that page: do not read them again through the legacy projections. With a
   real row/field gap, read only that gap from the SAME handle, keeping identity
   columns and ordinals. A metadata-only read covers metadata only. A WHERE that
   excludes VENDOR_METRICS cannot establish that those Vendors are missing.
5. When has-more=true, require next-after-ordinal strictly greater than the request
   cursor and advance to exactly that value. A page with no new noncontrol
   ordinals is no progress. When has-more=false, finish source pagination; the
   returned next-after-ordinal=0 is a sentinel, not a new first-page request.
   Count repeated control once; union ordinals and reconcile expected-record-count.
   Keep reads/continuations serial within the Country. Complete its bindings and
   prepare its report section before opening the next Country.

The initial full page read can validate the Country control before interpreting
other record types; control-first interpretation does not require a separate tool
call. A page can split one Vendor across source pages: bind the identity, then
complete its missing records from the known pages before marking it verified.

### Working evidence and progress

Maintain working notes (a workspace file if ordinary file tools are available,
otherwise structured task notes) with these two records. They are not a new host
service, mandatory output format, business data source or installed hard gate.
Never describe a note you did not actually save as persistent state.

- Page: request scope/cursor/size → actual execute call/handle/capture/environment
  → actual read call/returned handle → expected count, fingerprint, unique ordinals,
  intact fields, truncation and precise remaining gaps. Keep actual rows/cells or
  their available original response reference; an identifier list is not the data.
- Vendor: full scope + Country/P/T/calendar (or CURRENT filters/denominator/capture),
  Vendor code and metric version → actual metrics, Code/Source/us rows/checks,
  coverage, per-record provenance, validation and delivery state. Preserve
  record_type, dimension, eta_value/row_kind and ordinal when partitioning.
  Bind by this identity, never rank position or Vendor name. Repeated counts on
  other record types do not override the metric row.

Before each Atlas call name the gap it will close: next source page, missing
ordinal/field, unresolved schema item or one diagnosed correction. After it,
record the new facts or the exact blocker. Reuse already complete row×field
coverage; a different SELECT is useful only if it supplies missing evidence.
Once a Country's required facts are bound, write its section from them; move to
remaining requested Countries and deliver when their finite worklists are done
or locally blocked. A local failure does not erase another Country's work.

All modes count source executions, retained reads, discovery, continuations,
corrections and elapsed time toward cost. After first-page metadata, estimate
remaining source pages as ceil(remaining_noncontrol_rows/page_size), plus actual
retained reads. For example expected170/page50 needs4 source pages, expected136
needs3; this is a planning estimate, not a hard cap. Compare actual work to remaining
gaps. When calls add no new rows/fields and there is no supported changed action,
end that path with verified facts and exact gaps instead of an unchanged loop.
Continue large finite requests while making progress; preserve their scope.

### Local recovery

| Evidence | Action |
|---|---|
| rows?/cells? true, or host explicitly reports omitted tool content | Read only missing ordinal windows/fields from the same handle, with identity. A complete tool read already available in context needs no replay. |
| Result reference unavailable | Use the actual response already present; if essential content truly is unavailable, recover that exact gap with the originating retained handle once and record the recovery. Repeated schema/source requests do not repair the reference. |
| Unknown EQL attribute | Correct that name from the declared EQL schema once; SQL underscores are not EQL hyphens. Keep business scope. |
| Selector/argument rejection | Follow section1's one changed correction; keep the handle. |
| DuckDB configuration failure such as locked memory_limit | Mark this retained read unavailable, retain prior complete reads. Retry only after evidence the condition changed or a supported different read closes the gap; identical SQL/projection/version switches and new source queries do not fix configuration. |
| Confirmed handle expiry | One exact-scope recapture, with new capture and completeness checks. |
| Source byte refusal | One evidenced size/projection correction; account for newly omitted fields. Smaller pages do not fix source aggregation time. |
| Fingerprint drift | One consistent recapture of the affected page union; then disclose instability if still inconsistent. |
| Read handle/cursor differs from request | Isolate dependent facts; inspect available raw correlation or report ASSOCIATION_ERROR/UNVERIFIED. Preserve independent scopes; never repair by similar values. |

At most one evidence-based changed correction per failed work item. An unchanged
rejected call or duplicate successful source page is not recovery. Completion
rules for typed business facts and final copy accuracy live in
[completion-contract.md](completion-contract.md).

## 4. Legacy single-handle report: typed projections

Use this only for report-query/rows or when an actual reader limit requires
lossless typed partitions. On paged report-v2, reuse any already-read fields and
include its page metadata/coverage as well. This is not a second checklist after
section3's complete read.

Use the full report EQL projection in structured-queries.eql before retaining the
result. Below are disjoint projections of the SAME handle, not new source SQL.
Country Control is separate from Vendor Metrics to avoid placeholder ambiguity.
The retained column names below must match the actual environment; if absent,
check actual schema, not approximate aliases. An unprojected field is unknown.

### A. Country Control — read and reconcile first

```sql
SELECT scope_key, record_type, country_code, vendor_code,
       previous_snapshot_date, target_snapshot_date, calendar_mode,
       selection_mode, metric_version, scope_status, business_timezone, queried_at_local,
       selected_vendor_count, selected_positive_coverage,
       previous_country_past_due_count, target_country_past_due_count,
       previous_country_open, target_country_open,
       previous_country_ratio, target_country_ratio,
       expected_record_count, row_ordinal
FROM data
WHERE record_type = 'COUNTRY_CONTROL'
ORDER BY row_ordinal
```

Require exactly one control for the requested scope. Match Country/P/T/calendar,
selection, metric version and scope key to the actual request; scope-status must
be OK. Compare the dedicated Country fields to the pinned monitor/history:

| Report COUNTRY_CONTROL | Monitor/history |
|---|---|
| previous_country_past_due_count / target_country_past_due_count | previous_past_due_count / target_past_due_count |
| previous_country_open / target_country_open | previous_open_count / target_open_count |
| previous_country_ratio / target_country_ratio | previous_past_due_ratio / target_past_due_ratio |

Counts must match exactly; apply documented tolerance for unrounded ratios.
`previous_past_due_count`, `target_past_due_count`, `previous_open_count`,
`target_open_count` on COUNTRY_CONTROL are NOT Country totals. Their zeros are
unrelated placeholders, not a failed cross-check. Do not interpret them.

If dedicated fields were not read, read them before asserting a mismatch. A true
mismatch is disclosed with both original values/captures; no blanket zero-value
exemption. Preserve independently verified report-scope facts with their dates
and denominators, but do not claim validated attribution of the monitor event
until cross-capture reconciliation succeeds. Handle/identity errors are stronger:
no dependent use merely because some numbers look reasonable.

### B. Vendor Metrics — returned ranking and Vendor quantities only

```sql
SELECT scope_key, record_type, country_code, vendor_code, vendor_name,
       previous_snapshot_date, target_snapshot_date, calendar_mode,
       selection_mode, metric_version, scope_status,
       contribution_rank, selected_vendor_count,
       previous_past_due_count, target_past_due_count, past_due_count_change,
       previous_open_count, target_open_count, previous_vendor_ratio, target_vendor_ratio,
       previous_country_contribution, target_country_contribution,
       delta_country_contribution, positive_contribution_share, selected_positive_coverage,
       expected_record_count, row_ordinal
FROM data
WHERE record_type = 'VENDOR_METRICS'
ORDER BY row_ordinal
```

Use returned contribution_rank for presentation; do not replace it with read
position or reselect Vendors. Match the complete set to selected_vendor_count.
Zero selected Vendors after OK control is an explicit empty selection, not an
error or permission to add negative Vendors.

### C. ETA summaries and checks — complete compact representation

```sql
SELECT scope_key, record_type, country_code, vendor_code, vendor_name,
       previous_snapshot_date, target_snapshot_date, calendar_mode,
       selection_mode, metric_version, scope_status,
       dimension, eta_value, row_kind, display_rank, other_bucket_count,
       previous_past_due_count, target_past_due_count, past_due_count_change,
       past_due_count_relative_change, delta_country_contribution,
       expected_bucket_count, increase_total, decrease_total, net_change,
       previous_total, target_total, previous_expected_total, target_expected_total,
       counts_match, required, expected_record_count, row_ordinal
FROM data
WHERE record_type IN ('ETA_CODE_SUMMARY','ETA_SOURCE_SUMMARY','US_SOURCE_SUMMARY','VENDOR_CHECK')
ORDER BY row_ordinal
```

Summary count fields refer to that bucket/Other, NOT Vendor totals. Read the
signed dimension totals from VENDOR_CHECK: previous_total, target_total,
increase_total, decrease_total, net_change and the expected totals. `us` expected
totals are conditional Code=US, not whole Vendor PD. Unrelated sparse fields on
check records are not substitute check values. Keep Code and Source separate.

### Paging and completion

The three projections together must cover the retained source result, including
control and checks. Keep a compact per-Country ledger: originating call/handle,
scope/P/T/version, expected source count, actual unique ordinals, selected Vendor
codes/ranks, and each dimension's retrieval/check/delivery state. This is an Agent
procedure, not a new persisted service or a substitute original evidence.

When a read is truncated or too large, partition C losslessly by known record_type
or stable row_ordinal windows using the live reader's supported WHERE/ORDER/LIMIT
syntax. Keep every identity column in every partition. Continue from the last
actually read ordinal; don't assume an omitted row was zero. Do not drop summaries
or checks to reduce output, and do not compare one partition's size to the whole
source count. Unexpected record types must be read/disclosed, not silently filtered.
Inspect row and cell flags on EVERY page. `row-count` is the retained table size.
`truncation.rows-total` and `truncation.rows-shown` are this SQL's output.
This SQL is complete when `rows?` is false, `cells?` is false, and `rows-shown`
equals `rows-total`. Render those rows in the report modules.

`expected_record_count` is the whole compact report, not one WHERE clause.
Add `rows-total` across the disjoint statements. When that sum equals
`expected_record_count`, retrieval is complete. Ten Vendor Metrics rows plus
167 other rows is 177: the other statement kept the Vendor rows, it did not
drop them. Same for 10 plus 144 against 154. Deliver Code, Source, signed
totals and the diagnosis from those returned rows.

Treat a read as truncated only when `rows?` is true, `cells?` is true, or
`rows-shown` is below `rows-total`. Then continue from the last `row_ordinal`.
Do not withhold the ETA section while its rows are already in a complete response.
The union of unique ordinals must still equal `expected_record_count`.
This verifies transport of the compact result, not all raw ETA buckets.

Source collection pagination is separate: a handle can contain only one source
page. Follow the playbook's source coverage rules. Never requery source per Vendor
to fix retained preview truncation. When a full read path is unavailable, name the
precise gap and keep dependent scope unverified rather than claim completion.
